// lib/widgets/typewriter_animated_text.dart
import 'package:flutter/material.dart';
import 'dart:async';

class TypewriterAnimatedText extends StatefulWidget {
  final String text;
  final VoidCallback? onAnimationComplete; // Make this optional

  const TypewriterAnimatedText(this.text,
      {super.key, this.onAnimationComplete});

  @override
  State<TypewriterAnimatedText> createState() => TypewriterAnimatedTextState();
}

class TypewriterAnimatedTextState extends State<TypewriterAnimatedText>
    with SingleTickerProviderStateMixin {
  String _animatedText = '';
  late Timer _timer;
  int _charIndex = 0;

  @override
  void initState() {
    super.initState();
    _startAnimation();
  }

  void _startAnimation() {
    _timer = Timer.periodic(const Duration(milliseconds: 40), (timer) {
      setState(() {
        if (_charIndex < widget.text.length) {
          _animatedText += widget.text[_charIndex];
          _charIndex++;
        } else {
          _timer.cancel();
          widget.onAnimationComplete?.call(); // Call if not null
        }
      });
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Text(_animatedText,
        style: const TextStyle(fontSize: 14, color: Colors.black));
  }
}
