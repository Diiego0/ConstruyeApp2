// ignore_for_file: library_private_types_in_public_api, use_super_parameters, use_build_context_synchronously

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:construyeapp/vista_preview_chat.dart';
import 'main.dart';
import 'inicio_chatbot_logic.dart';

class HistorialChat extends StatefulWidget {
  const HistorialChat({Key? key}) : super(key: key);

  @override
  _HistorialChatState createState() => _HistorialChatState();
}

class _HistorialChatState extends State<HistorialChat> with SingleTickerProviderStateMixin {
  Map<String, dynamic> chatHistory = {};
  late AnimationController _animationController;
  late Animation<double> _animation;
  List<MapEntry<String, dynamic>> sortedChats = [];
  @override
  void initState() {
    super.initState();
    _loadChatHistory();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _animation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final chatHistoryString = prefs.getString('chat_history');
    if (kDebugMode) {
      print("Chat history string from SharedPreferences: $chatHistoryString");
    }

    if (chatHistoryString != null && chatHistoryString.isNotEmpty) {
      try {
        final decodedData = json.decode(chatHistoryString);
        if (kDebugMode) {
          print("Decoded chat history: $decodedData");
        }
        if (decodedData is Map<String, dynamic>) {
          setState(() {
            chatHistory = decodedData;
            // Convertir el Map a una lista de entradas y ordenarla
            sortedChats = chatHistory.entries.toList()
              ..sort((a, b) {
                final dateA = DateTime.parse(a.value['lastModified'] as String);
                final dateB = DateTime.parse(b.value['lastModified'] as String);
                return dateB.compareTo(dateA); // Ordenar de más reciente a más antiguo
              });
          });
        } else {
          if (kDebugMode) {
            print("Decoded data is not a Map<String, dynamic>");
          }
        }
      } catch (e) {
        if (kDebugMode) {
          print("Error decoding chat history: $e");
        }
      }
    } else {
      if (kDebugMode) {
        print("No chat history found in SharedPreferences");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    Color bubbleColor = isDarkMode ? primaryColorDarkMode : primaryColor;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Historial de Chats', 
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)
        ),
        backgroundColor: bubbleColor,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: AnimatedBuilder(
        animation: _animation,
        builder: (context, child) {
          return Opacity(
            opacity: _animation.value,
            child: child,
          );
        },
        child: sortedChats.isEmpty
            ? _buildEmptyState()
            : _buildChatList(bubbleColor),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.chat_bubble_outline,
            size: 80,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'No hay historial de chats',
            style: TextStyle(
              fontSize: 18, 
              color: Colors.grey[600], 
              fontWeight: FontWeight.w500
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatList(Color bubbleColor) {
    return ListView.builder(
      itemCount: sortedChats.length,
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemBuilder: (context, index) {
        final chatEntry = sortedChats[index];
        final chatId = chatEntry.key;
        final chatData = chatEntry.value as Map<String, dynamic>;
        final lastModified = DateTime.parse(chatData['lastModified'] as String);
        final formattedDate = DateFormat('dd/MM/yyyy HH:mm').format(lastModified);
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: _buildChatCard(bubbleColor, chatId, formattedDate, chatData['size']),
        );
      },
    );
  }

  Widget _buildChatCard(Color bubbleColor, String chatId, String formattedDate, int size) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _openChat(context, chatId),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                backgroundColor: bubbleColor,
                child: const Icon(Icons.chat, color: Colors.white),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Chat ID: $chatId',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Última modificación: $formattedDate',
                      style: TextStyle(color: Colors.grey[600], fontSize: 14),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Tamaño: ${(size / 1024).toStringAsFixed(2)} KB',
                      style: TextStyle(color: Colors.grey[600], fontSize: 14),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }


  void _openChat(BuildContext context, String chatId) async {
    InicioChatBotLogic tempLogic = InicioChatBotLogic(
      onMessagesUpdated: (_) {},
      onWaitingForResponseChanged: (_) {},
      onChatClosed: () {},
    );

    await tempLogic.loadChatFromHistory(chatId);

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => VistaPreviewChat(
          chatId: chatId,
          messages: tempLogic.messages,
        ),
      ),
    );
  }
}

