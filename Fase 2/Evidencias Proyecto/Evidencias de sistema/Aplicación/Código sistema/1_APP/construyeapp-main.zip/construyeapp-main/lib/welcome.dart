import 'package:flutter/material.dart';
import 'main.dart';

class Welcome extends StatelessWidget {
  const Welcome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: primaryColor,
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              // Definimos breakpoints para diferentes tamaños de pantalla
              final isSmallPhone = constraints.maxWidth < 360;
              final isTablet = constraints.maxWidth >= 600;

              // Ajustamos los tamaños basados en el ancho de la pantalla
              final double logoWidth = isTablet ? 0.5 : 0.8;
              final double titleFontSize = isSmallPhone ? 0.06 : (isTablet ? 0.05 : 0.07);
              final double iconSize = isSmallPhone ? 0.2 : (isTablet ? 0.15 : 0.25);
              final double buttonFontSize = isSmallPhone ? 0.035 : (isTablet ? 0.03 : 0.04);
              final double buttonWidth = isTablet ? 0.4 : 0.6;

              return SingleChildScrollView(
                child: ConstrainedBox(
                  constraints: BoxConstraints(minHeight: constraints.maxHeight),
                  child: IntrinsicHeight(
                    child: Padding(
                      padding: EdgeInsets.all(constraints.maxWidth * (isTablet ? 0.04 : 0.06)),
                      child: Column(
                        children: [
                          Image.asset(
                            'assets/images/logo_cchc.png',
                            width: constraints.maxWidth * logoWidth,
                          ),
                          SizedBox(height: constraints.maxHeight * 0.04),
                          Text(
                            'BOT EL\nCONSTRUCTOR',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: constraints.maxWidth * titleFontSize,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          SizedBox(height: constraints.maxHeight * 0.04),
                          Container(
                            width: constraints.maxWidth * (isTablet ? 0.3 : 0.4),
                            height: constraints.maxWidth * (isTablet ? 0.3 : 0.4),
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                            ),
                            child: Center(
                              child: Icon(
                                Icons.smart_toy,
                                size: constraints.maxWidth * iconSize,
                                color: Colors.grey,
                              ),
                            ),
                          ),
                          SizedBox(height: constraints.maxHeight * 0.02),
                          Expanded(
                            child: Center(
                              child: ConstrainedBox(
                                constraints: BoxConstraints(
                                  maxWidth: constraints.maxWidth * buttonWidth,
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    ElevatedButton(
                                      onPressed: () => Navigator.pushNamed(context, '/login'),
                                      style: ElevatedButton.styleFrom(
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(8),
                                        ),
                                        padding: EdgeInsets.symmetric(vertical: constraints.maxHeight * (isTablet ? 0.015 : 0.02)),
                                      ),
                                      child: Text('Iniciar Sesión', style: TextStyle(fontSize: constraints.maxWidth * buttonFontSize)),
                                    ),
                                    SizedBox(height: constraints.maxHeight * 0.02),
                                    ElevatedButton(
                                      onPressed: () => Navigator.pushNamed(context, '/registro'),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.grey[700],
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(8),
                                        ),
                                        padding: EdgeInsets.symmetric(vertical: constraints.maxHeight * (isTablet ? 0.015 : 0.02)),
                                      ),
                                      child: Text('Regístrate', 
                                        style: TextStyle(color: Colors.white, fontSize: constraints.maxWidth * buttonFontSize)),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: constraints.maxHeight * 0.02),
                          Image.asset(
                            'assets/images/logo_citt.png',
                            width: constraints.maxWidth * (isTablet ? 0.2 : 0.25),
                            height: constraints.maxWidth * (isTablet ? 0.2 : 0.25),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}