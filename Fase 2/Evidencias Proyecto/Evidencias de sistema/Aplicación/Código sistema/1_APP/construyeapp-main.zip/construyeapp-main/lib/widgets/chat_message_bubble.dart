// lib/widgets/chat_message_bubble.dart
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:url_launcher/url_launcher.dart';
import 'typewriter_animated_text.dart';

class ChatMessage {
  final String id;
  final String text;
  final bool isUser;
  final String senderName;
  bool hasAnimated;
  final List<Citation>? citations;

  ChatMessage({
    required this.id,
    required this.text,
    required this.isUser,
    required this.senderName,
    this.hasAnimated = false,
    this.citations,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'text': text,
    'isUser': isUser,
    'senderName': senderName,
    'citations': citations?.map((c) => c.toJson()).toList(),
  };

  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
    id: json['id'],
    text: json['text'],
    isUser: json['isUser'],
    senderName: json['senderName'],
    citations: json['citations'] != null
        ? (json['citations'] as List)
            .map((c) => Citation.fromJson(c))
            .toList()
        : null,
  );
}

class Citation {
  final int position;
  final String text;
  final String? url;
  final String? title;

  Citation({
    required this.position,
    required this.text,
    this.url,
    this.title,
  });

  Map<String, dynamic> toJson() => {
    'position': position,
    'text': text,
    if (url != null) 'url': url,
    if (title != null) 'title': title,
  };

  factory Citation.fromJson(Map<String, dynamic> json) => Citation(
    position: json['position'],
    text: json['text'],
    url: json['url'],
    title: json['title'],
  );
}

class MessageBubble extends StatefulWidget {
  final ChatMessage message;
  final bool isLastMessage;

  const MessageBubble({
    super.key,
    required this.message,
    required this.isLastMessage,
  });

  @override
  State<MessageBubble> createState() => _MessageBubbleState();
}

class _MessageBubbleState extends State<MessageBubble> {
  bool _showReferences = false;



Future<void> _launchURL(String urlString) async {
  try {
    if (kDebugMode) {
      print('URL original: $urlString');
    }
    
    // Convertir HTTP a HTTPS si es necesario
    String secureUrl = urlString;
    if (urlString.startsWith('http://')) {
      secureUrl = 'https://${urlString.substring(7)}';
    }
    
    if (kDebugMode) {
      print('Intentando abrir URL segura: $secureUrl');
    }
    
    final Uri url = Uri.parse(secureUrl);
    
    // Intentar abrir directamente sin verificar canLaunchUrl
    await launchUrl(
      url,
      mode: LaunchMode.inAppWebView,
      webViewConfiguration: const WebViewConfiguration(
        enableJavaScript: true,
        enableDomStorage: true,
      ),
    ).catchError((error) {
      if (kDebugMode) {
        print('Error al abrir URL: $error');
      }
      // Intentar modo alternativo si falla el WebView
      return launchUrl(
        url,
        mode: LaunchMode.externalApplication,
      );
    });
    
  } catch (e) {
    if (kDebugMode) {
      print('Error al abrir URL: $e');
    }
  }
}



  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      child: Align(
        alignment: widget.message.isUser ? Alignment.centerRight : Alignment.centerLeft,
        child: Column(
          crossAxisAlignment: widget.message.isUser 
              ? CrossAxisAlignment.end 
              : CrossAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: widget.message.isUser ? Colors.black87 : Colors.grey[200],
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.message.senderName,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: widget.message.isUser ? Colors.white : Colors.black,
                    ),
                  ),
                  const SizedBox(height: 5),
                  if (widget.message.isUser || !widget.isLastMessage || widget.message.hasAnimated)
                    _buildFormattedText()
                  else
                    TypewriterAnimatedText(
                      widget.message.text,
                      onAnimationComplete: () {
                        setState(() {
                          widget.message.hasAnimated = true;
                        });
                      },
                    ),
                ],
              ),
            ),
            if (!widget.message.isUser && 
                widget.message.citations?.isNotEmpty == true &&
                _showReferences)
              _buildReferences(),
            if (!widget.message.isUser && 
                widget.message.citations?.isNotEmpty == true)
            GestureDetector(
              onTap: () => setState(() {
                _showReferences = !_showReferences;
              }),
              child: Padding(
                padding: const EdgeInsets.only(left: 16, top: 4),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      _showReferences 
                          ? Icons.keyboard_arrow_up 
                          : Icons.keyboard_arrow_down,
                      size: 16,
                      color: Colors.black,  // También puedes cambiar el color del ícono si quieres
                    ),
                    Text(
                      _showReferences ? 'Ocultar referencias' : 'Ver referencias',
                      style: const TextStyle(
                        color: Color.fromARGB(255, 255, 255, 255),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFormattedText() {
    final textSpans = <TextSpan>[];
    final pattern = RegExp(r'\[(\d+)\]');
    final textParts = widget.message.text.split(pattern);
    
    for (var i = 0; i < textParts.length; i++) {
      // Añadir el texto normal
      if (textParts[i].isNotEmpty) {
        textSpans.add(TextSpan(
          text: textParts[i],
          style: TextStyle(
            color: widget.message.isUser ? Colors.white : Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ));
      }
      
      // Añadir la referencia si existe
      if (i < textParts.length - 1) {
        final refNumber = int.tryParse(textParts[i + 1]);
        if (refNumber != null) {
          textSpans.add(TextSpan(
            text: '[$refNumber]',
            style: TextStyle(
              color: widget.message.isUser ? Colors.white70 : Colors.blue,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
            recognizer: TapGestureRecognizer()
              ..onTap = () => _showReferenceDialog(refNumber),
          ));
          i++; // Saltar la siguiente parte ya que ya la procesamos
        }
      }
    }

    return SelectableText.rich(
      TextSpan(children: textSpans),
    );
  }

Widget _buildReferences() {
    return Container(
      margin: const EdgeInsets.only(top: 4, left: 16),
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: widget.message.citations!.map((citation) {
          bool isRealUrl = citation.url != null && 
                          citation.url!.startsWith('http') && 
                          !citation.url!.startsWith('cite:') &&
                          !citation.url!.toLowerCase().endsWith('.pdf');

          if (isRealUrl) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: GestureDetector(
                onTap: () {
                  // Llamar directamente a _launchURL sin verificar canLaunchUrl
                  _launchURL(citation.url!);
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '[${citation.position}] ',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                      ),
                    ),
                    Expanded(
                      child: Text(
                        citation.title ?? citation.text,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.blue,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                    const Icon(
                      Icons.open_in_new,
                      size: 12,
                      color: Colors.blue,
                    ),
                  ],
                ),
              ),
            );
          } else {
            // El resto del código para referencias de texto y PDFs permanece igual
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: GestureDetector(
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      backgroundColor: Colors.white,
                      title: Text(
                        'Referencia ${citation.position}',
                        style: const TextStyle(
                          color: Colors.black87,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      content: SingleChildScrollView(
                        child: Text(
                          citation.text,
                          style: const TextStyle(
                            color: Colors.black87,
                          ),
                        ),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.of(context).pop(),
                          child: const Text(
                            'Cerrar',
                            style: TextStyle(
                              color: Color.fromARGB(255, 23, 112, 192),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  );
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '[${citation.position}] ',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                      ),
                    ),
                    Expanded(
                      child: Text(
                        citation.title ?? citation.text,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[800],
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ),
                    Icon(
                      Icons.info_outline,
                      size: 12,
                      color: Colors.grey[600],
                    ),
                  ],
                ),
              ),
            );
          }
        }).toList(),
      ),
    );
  }

  void _showReferenceDialog(int refNumber) {
    final citation = widget.message.citations?.firstWhere(
      (c) => c.position == refNumber,
      orElse: () => Citation(
        position: refNumber,
        text: 'Referencia no encontrada',
      ),
    );

    if (citation != null) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Referencia $refNumber'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(citation.text),
                if (citation.url != null) ...[
                  const SizedBox(height: 16),
                  TextButton.icon(
                    icon: const Icon(Icons.open_in_new),
                    label: const Text('Abrir enlace'),
                    onPressed: () {
                      if (citation.url != null) {
                        _launchURL(citation.url!);
                        Navigator.of(context).pop();
                      }
                    },
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cerrar'),
            ),
          ],
        ),
      );
    }
  }
}