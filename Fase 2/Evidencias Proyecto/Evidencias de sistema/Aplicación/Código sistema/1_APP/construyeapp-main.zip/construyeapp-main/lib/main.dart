// ignore_for_file: use_build_context_synchronously

import 'dart:async';
import 'dart:convert';
import 'package:construyeapp/widgets/event_tracker.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'auth_service.dart';
import 'inicio_chatbot_logic.dart';
import 'inicio_chatbot_ui.dart';
import 'welcome.dart';
import 'login.dart';
import 'registro.dart';
import 'perfil.dart';
import 'historial_chat.dart';
import 'soporte_tecnico.dart';
import 'vista_preview_chat.dart';

String idUsuario = '';
Color primaryColor = const Color.fromARGB(255, 23, 112, 192);
Color primaryColorLight = const Color.fromARGB(255, 139, 200, 255);
Color secundaryColor = const Color.fromARGB(255, 255, 55, 40);
Color greyColor = const Color.fromARGB(255, 88, 79, 79);
Color greyColorLight = const Color.fromARGB(255, 217, 217, 217);
Color hyperLinkColor = const Color.fromARGB(255, 0, 41, 255);
Color primaryColorDarkMode = const Color.fromARGB(255, 41, 41, 41);
bool isDarkMode = false;
final StreamController<String> chatEventController = StreamController<String>.broadcast();

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  if (kDebugMode) {
    print('Handling a background message: ${message.messageId}');
  }

  tracker.capture(
    eventName: 'Background_Message_Received',
    properties: {
      'has_notification': message.notification != null,
      'has_data': message.data.isNotEmpty,
      'data_action': message.data['action'] ?? 'none',
    },
  );

  if (message.data['action'] == 'clearCredentials') {
    final logic = InicioChatBotLogic(
      onMessagesUpdated: (_) {},
      onWaitingForResponseChanged: (_) {},
      onChatClosed: () {},
    );
    await logic.reiniciarChat();
    tracker.capture(eventName: 'Chat_Reset_Background');
  }
}

Future<void> _requestAppReview(BuildContext context, Function(void Function()) setState) async {
  double? selectedRating;
  TextEditingController commentController = TextEditingController();
  await showDialog(
    context: context,
    builder: (BuildContext context) {
      return StatefulBuilder(
        builder: (context, setStateDialog) {
          return AlertDialog(
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            contentPadding: EdgeInsets.all(20),
            content: SizedBox(
              width: MediaQuery.of(context).size.width * 0.8,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircleAvatar(
                    backgroundColor: Colors.grey[300],
                    radius: 30,
                    child: Icon(Icons.smart_toy, size: 40, color: Colors.grey[700]),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Construye++",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Califica nuestra App",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(5, (index) {
                      return IconButton(
                        icon: Icon(
                          index < (selectedRating ?? 0) ? Icons.star : Icons.star_border,
                          color: Colors.amber,
                          size: 30,
                        ),
                        onPressed: () {
                          setStateDialog(() {
                            selectedRating = (index + 1).toDouble();
                          });
                        },
                      );
                    }),
                  ),
                  SizedBox(height: 10),
                  TextField(
                    controller: commentController,
                    decoration: InputDecoration(
                      hintText: "Déjanos tus comentarios",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                    maxLines: 3,
                  ),
                  SizedBox(height: 15),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: primaryColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      minimumSize: Size(double.infinity, 40),
                    ),
                    onPressed: () async {
                      if (selectedRating != null && commentController.text.isNotEmpty) {
                        await _sendReview(selectedRating!, commentController.text);
                        
                        // Aquí es donde deberíamos resetear la bandera, después de enviar la reseña
                        final prefs = await SharedPreferences.getInstance();
                        await prefs.setBool('should_request_review', false);
                        
                        Navigator.of(context).pop();
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text("Debes proporcionar una calificación y un comentario."),
                          ),
                        );
                      }
                    },
                    child: Text(
                      "Enviar",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}

// Enviar los datos a la API
Future<void> _sendReview(double rating, String comment) async {
  const apiUrl = 'http://construyeadmin.azurewebsites.net/api/calificaciones/';
  final prefs = await SharedPreferences.getInstance();
  String? rut = prefs.getString('rut');

  if (rut == null) {
    if (kDebugMode) {
      print('Error: RUT no encontrado en SharedPreferences.');
    }
    tracker.capture(
      eventName: 'Review_Error',
      properties: {'error': 'RUT no encontrado'}
    );
    return;
  }

  try {
    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'usuario': rut,
        'puntuacion': rating,
        'comentario': comment,
      }),
    );

    if (response.statusCode == 200) {
      if (kDebugMode) {
        print("Reseña enviada correctamente");
      }
      tracker.capture(
        eventName: 'Review_Submitted',
        properties: {
          'rating': rating,
          'comment_length': comment.length,
          'success': true,
        },
      );
    } else {
      if (kDebugMode) {
        print("Error al enviar la reseña: ${response.statusCode}");
      }
      tracker.capture(
        eventName: 'Review_Failed',
        properties: {
          'status_code': response.statusCode,
          'rating': rating,
        },
      );
    }
  } catch (e) {
    tracker.capture(
      eventName: 'Review_Exception',
      properties: {'error': e.toString()}
    );
  }
}



// Verificar si el usuario ha interactuado con el chatbot
Future<void> _checkChatbotInteraction() async {
  final prefs = await SharedPreferences.getInstance();
  bool hasInteractedWithChatbot = prefs.getBool('has_interacted_with_chatbot') ?? false;

  tracker.capture(
    eventName: 'Chatbot_Interaction_Check',
    properties: {'has_interacted': hasInteractedWithChatbot}
  );

  if (hasInteractedWithChatbot) {
    prefs.setBool('should_request_review', true);
    tracker.capture(eventName: 'Review_Request_Queued');
  }
}

Future<void> _checkNotificationPermissions() async {
  try {
    // Solo para Android 13 (API level 33) y superior
    if (defaultTargetPlatform == TargetPlatform.android) {
      // Esto mostrará el diálogo del sistema para solicitar permisos
      final status = await Permission.notification.request();
      
      if (kDebugMode) {
        print('Estado del permiso de notificación: $status');
      }

      if (status.isPermanentlyDenied) {
        // Si el usuario ha denegado permanentemente los permisos,
        // podemos abrir la configuración del sistema
        openAppSettings();
      }
    }
  } catch (e) {
    if (kDebugMode) {
      print('Error al verificar permisos: $e');
    }
  }
}


Future<void> _identifyUserInTracker() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  String? rut = prefs.getString('rut');
  String? name = prefs.getString('name');

  if (rut != null && rut.isNotEmpty) {
    await tracker.identify(
      rut,
      userProperties: {
        'name': name ?? 'Usuario sin nombre',
      },
    );
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await _checkNotificationPermissions();
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('@mipmap/ic_launcher');
  const InitializationSettings initializationSettings =
      InitializationSettings(android: initializationSettingsAndroid);
  await flutterLocalNotificationsPlugin.initialize(initializationSettings);
  await initNotifications();
  _initializeFirebaseMessaging();

  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp])
      .then((_) async {
    runApp(const MyApp());
  });
}

Future<void> initNotifications() async {
  if (kDebugMode) {
    print('Iniciando configuración de canal de notificaciones');
  }

  try {
    final AndroidNotificationChannel channel = const AndroidNotificationChannel(
      'general_notifications',
      'General Notifications',
      importance: Importance.max,
      playSound: true,
      enableVibration: true,
      enableLights: true,
      showBadge: true,
    );

    await flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel)
        .then((_) {
      if (kDebugMode) {
        print('Canal de notificaciones creado exitosamente');
      }
    }).catchError((error) {
      if (kDebugMode) {
        print('Error al crear canal de notificaciones: $error');
      }
    });
  } catch (e) {
    if (kDebugMode) {
      print('Error en initNotifications: $e');
    }
  }
}

void _initializeFirebaseMessaging() {
  FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
    if (kDebugMode) {
      print('Recibido mensaje en primer plano:');
      print('Notification: ${message.notification?.toMap()}');
      print('Data: ${message.data}');
    }

    RemoteNotification? notification = message.notification;

    // Verificar si tenemos una notificación válida
    if (notification != null) {
      if (kDebugMode) {
        print('Procesando notificación para mostrar');
      }
      await _showNotification(notification);
    } else {
      if (kDebugMode) {
        print('Notificación recibida es null');
      }
    }

    if (message.data['action'] == 'clearCredentials') {
      chatEventController.add('chat_closed');
      
      tracker.capture(
        eventName: 'Chat_Closed',
        properties: {'trigger': 'firebase_message'}
      );
      
      final logic = InicioChatBotLogic(
        onMessagesUpdated: (_) {},
        onWaitingForResponseChanged: (_) {},
        onChatClosed: () {},
      );
      await logic.reiniciarChat();
    }
  });
}

Future<void> _showNotification(RemoteNotification notification) async {
  if (kDebugMode) {
    print('Intentando mostrar notificación');
    print('Título: ${notification.title}');
    print('Cuerpo: ${notification.body}');
  }

  try {
    // Crear un ID único para cada notificación
    final id = DateTime.now().millisecondsSinceEpoch.remainder(100000);

    AndroidNotificationDetails androidPlatformChannelSpecifics =
        const AndroidNotificationDetails(
      'general_notifications',
      'General Notifications',
      importance: Importance.max,
      priority: Priority.high,
      showWhen: true,  // Cambiar a true
      enableVibration: true,
      playSound: true,
      icon: '@mipmap/ic_launcher',
      // Agregar estas configuraciones
      enableLights: true,
      visibility: NotificationVisibility.public,
      styleInformation: BigTextStyleInformation(''),
    );

    NotificationDetails platformChannelSpecifics =
        NotificationDetails(android: androidPlatformChannelSpecifics);

    await flutterLocalNotificationsPlugin.show(
      id,
      notification.title ?? 'Notificación',
      notification.body ?? '',
      platformChannelSpecifics,
    ).then((_) {
      if (kDebugMode) {
        print('Notificación mostrada exitosamente');
      }
    }).catchError((error) {
      if (kDebugMode) {
        print('Error al mostrar la notificación: $error');
      }
    });
  } catch (e) {
    if (kDebugMode) {
      print('Error en _showNotification: $e');
    }
  }
}


class TrackingRouteObserver extends RouteObserver<PageRoute> {
  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPush(route, previousRoute);
    if (route is PageRoute) {
      tracker.capture(
        eventName: 'Screen_View',
        properties: {
          'screen': route.settings.name ?? 'unknown',
          'previous_screen': previousRoute?.settings.name,
        },
      );
    }
  }

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPop(route, previousRoute);
    if (previousRoute is PageRoute) {
      tracker.capture(
        eventName: 'Screen_View',
        properties: {
          'screen': previousRoute.settings.name ?? 'unknown',
          'previous_screen': route.settings.name,
          'action': 'back',
        },
      );
    }
  }
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final _trackingObserver = TrackingRouteObserver();  // Agregar esta línea
  @override
  void initState() {
    super.initState();
    _checkChatbotInteraction();
    _identifyUserInTracker();
  }



  @override
  Widget build(BuildContext context) {
    tracker.capture(
      eventName: 'App_Started',
      properties: {
        'platform': 'mobile',
        'os': 'android',
        'dark_mode': isDarkMode,
        'timestamp': DateTime.now().toIso8601String(),
      },
    );
    return MaterialApp(
      navigatorObservers: [_trackingObserver],  // Agregar esta línea
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: primaryColor,
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.white,
            foregroundColor: Colors.black,
            minimumSize: const Size(double.infinity, 50),
          ),
        ),
      ),
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('es', ''), // Español
        Locale('en', ''), // Inglés
      ],
      home: FutureBuilder<String?>(
        future: AuthService().getToken(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              body: Center(
                child: CircularProgressIndicator(),
              ),
            );
          }
          if (snapshot.hasData && snapshot.data != null) {
            return FutureBuilder<bool>(
              future: _shouldRequestReview(),
              builder: (context, shouldReviewSnapshot) {
                if (shouldReviewSnapshot.hasData && shouldReviewSnapshot.data == true) {
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    _requestAppReview(context, setState);
                  });
                }
                return const InicioChatBot();
              },
            );
          }
          return const Welcome();
        },
      ),

      routes: {
        '/login': (context) => const Login(),
        '/registro': (context) => const Registro(),
        '/inicio_chatbot': (context) => const InicioChatBot(),
        '/perfil': (context) => const Perfil(),
        '/historial': (context) => const HistorialChat(),
        '/soporte': (context) => const SoporteTecnico(),
        '/vista_preview_chat': (context) =>
            const VistaPreviewChat(chatId: '', messages: []),
      },
    );
  }
  Future<bool> _shouldRequestReview() async {
    final prefs = await SharedPreferences.getInstance();
    bool shouldRequest = prefs.getBool('should_request_review') ?? false;
    bool hasShown = prefs.getBool('has_shown_review') ?? false;  // Nueva bandera
    
    if (shouldRequest && !hasShown) {
      await prefs.setBool('has_shown_review', true);  // Marcar como mostrado
      return true;
    }
    return false;
  }
}