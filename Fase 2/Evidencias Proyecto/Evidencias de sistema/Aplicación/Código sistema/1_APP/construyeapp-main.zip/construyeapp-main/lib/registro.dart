// ignore_for_file: use_build_context_synchronously

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'main.dart';
import 'urls.dart';

class Registro extends StatefulWidget {
  const Registro({Key? key}) : super(key: key);

  @override
  _RegistroState createState() => _RegistroState();
}

class _RegistroState extends State<Registro> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nombreController = TextEditingController();
  final TextEditingController _apellidoController = TextEditingController();
  final TextEditingController _rutController = TextEditingController();
  final TextEditingController _numeroController = TextEditingController();
  final TextEditingController _correoController = TextEditingController();
  final TextEditingController _empresaController = TextEditingController();
  final TextEditingController _cargoController = TextEditingController();
  final TextEditingController _centroObraController = TextEditingController();
  final TextEditingController _numeroSocioController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  String _tipoUsuario = 'normal';
  bool _isLoading = false;
  String _errorMessage = '';

  // Reemplaza esta URL con la de tu función Azure para el registro
  final String url = urlRegistro;

  bool isValidEmail(String email) {
    bool isValid = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email);
    if (!isValid) {
      if (kDebugMode) {
        print('[ERROR] Correo inválido: $email');
      }
    }
    return isValid;
  }

  bool isValidRut(String rut) {
    bool isValid = RegExp(r'^\d{1,8}-[0-9kK]$').hasMatch(rut);
    if (!isValid) {
      if (kDebugMode) {
        print('[ERROR] RUT inválido: $rut');
      }
    }
    return isValid;
  }

  Future<void> _registrar() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
        _errorMessage = '';
      });

      _formKey.currentState!.save();

      try {
        final Map<String, dynamic> registroData = {
          'tipoUsuario': _tipoUsuario,
          'nombre': _nombreController.text,
          'apellido': _apellidoController.text,
          'rut': _rutController.text,
          'numero': _numeroController.text,
          'correo': _correoController.text,
          'password': _passwordController.text,
        };

        if (_tipoUsuario == 'socio') {
          registroData.addAll({
            'empresa': _empresaController.text,
            'cargo': _cargoController.text,
            'centroObra': _centroObraController.text,
            'numeroSocio': _numeroSocioController.text,
          });
        }
        if (kDebugMode) {
            print('[INFO] URL de registro completa: $url');
            print('[INFO] Datos que se enviarán: ${jsonEncode(registroData)}');
        }
        if (kDebugMode) {
          print('[INFO] Intentando registro para usuario: ${registroData['correo']}');
        }
        
        final response = await http.post(
          Uri.parse(url),
          headers: <String, String>{
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: jsonEncode(registroData),
        );

        if (response.statusCode == 200) {
          if (kDebugMode) {
            print('[INFO] Registro exitoso para: ${registroData['correo']}');
          }
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Registro exitoso')),
          );
          Navigator.pushNamed(context, '/login');
        } else {
          if (kDebugMode) {
            print('[ERROR] Error en registro - Status: ${response.statusCode}');
          }
          if (kDebugMode) {
            print('[ERROR] Respuesta: ${response.body}');
          }
          setState(() {
            _errorMessage = 'Error en el registro: ${response.body}';
          });
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(_errorMessage)),
          );
        }
      } catch (e) {
        if (kDebugMode) {
          print('[ERROR] Excepción durante el registro: $e');
        }
        setState(() {
          _errorMessage = 'Error de conexión: $e';
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(_errorMessage)),
        );
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    } else {
      if (kDebugMode) {
        print('[ERROR] Validación del formulario falló');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: primaryColor,
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final isTablet = constraints.maxWidth >= 600;
              final double logoWidth = isTablet ? 0.4 : 0.6;
              final double fontSize = isTablet ? 0.025 : 0.04;
              final double fieldSpacing =
                  constraints.maxHeight * (isTablet ? 0.021 : 0.02);
              final double horizontalPadding =
                  constraints.maxWidth * (isTablet ? 0.1 : 0.05);

              return SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: horizontalPadding,
                    vertical: constraints.maxHeight * 0.03,
                  ),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        Image.asset(
                          'assets/images/logo_cchc.png',
                          width: constraints.maxWidth * logoWidth,
                        ),
                        SizedBox(height: fieldSpacing * 2),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Tipo de Usuario:',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: constraints.maxWidth * fontSize,
                              ),
                            ),
                            Row(
                              children: [
                                Radio<String>(
                                  value: 'normal',
                                  groupValue: _tipoUsuario,
                                  onChanged: (value) {
                                    setState(() {
                                      _tipoUsuario = value!;
                                    });
                                  },
                                  fillColor:
                                      MaterialStateProperty.resolveWith<Color>(
                                          (Set<MaterialState> states) {
                                    return Colors.white;
                                  }),
                                ),
                                Text(
                                  'Usuario Normal',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: constraints.maxWidth * fontSize,
                                  ),
                                ),
                                Radio<String>(
                                  value: 'socio',
                                  groupValue: _tipoUsuario,
                                  onChanged: (value) {
                                    setState(() {
                                      _tipoUsuario = value!;
                                    });
                                  },
                                  fillColor:
                                      MaterialStateProperty.resolveWith<Color>(
                                          (Set<MaterialState> states) {
                                    return Colors.white;
                                  }),
                                ),
                                Text(
                                  'Socio',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: constraints.maxWidth * fontSize,
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: fieldSpacing),
                            _buildTextField(constraints, 'Nombre', fontSize,
                                controller: _nombreController),
                            SizedBox(height: fieldSpacing),
                            _buildTextField(constraints, 'Apellido', fontSize,
                                controller: _apellidoController),
                            SizedBox(height: fieldSpacing),
                            _buildTextField(constraints, 'RUT', fontSize,
                                controller: _rutController, validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Por favor ingrese su RUT';
                              }
                              if (!isValidRut(value)) {
                                return 'Ingrese un RUT válido';
                              }
                              return null;
                            }),
                            SizedBox(height: fieldSpacing),
                            _buildTextField(
                              constraints,
                              'Número Teléfono',
                              fontSize,
                              controller: _numeroController,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Por favor ingrese su número de teléfono';
                                }
                                return null;
                              },
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly
                              ], // Solo permite números
                            ),
                            SizedBox(height: fieldSpacing),
                            _buildTextField(constraints, 'Correo', fontSize,
                                controller: _correoController,
                                validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Por favor ingrese su correo';
                              }
                              if (!isValidEmail(value)) {
                                return 'Ingrese un correo válido';
                              }
                              return null;
                            }),
                            if (_tipoUsuario == 'socio') ...[
                              SizedBox(height: fieldSpacing),
                              _buildTextField(constraints, 'Empresa', fontSize,
                                  controller: _empresaController),
                              SizedBox(height: fieldSpacing),
                              _buildTextField(constraints, 'Cargo', fontSize,
                                  controller: _cargoController),
                              SizedBox(height: fieldSpacing),
                              _buildTextField(
                                  constraints, 'Centro de obra', fontSize,
                                  controller: _centroObraController),
                              SizedBox(height: fieldSpacing),
                              _buildTextField(
                                  constraints, 'Número de socio', fontSize,
                                  controller: _numeroSocioController),
                            ],
                            SizedBox(height: fieldSpacing),
                            _buildTextField(constraints, 'Contraseña', fontSize,
                                isPassword: true,
                                controller: _passwordController),
                            SizedBox(height: fieldSpacing),
                            _buildTextField(
                                constraints, 'Repetir Contraseña', fontSize,
                                isPassword: true,
                                controller: _confirmPasswordController,
                                validator: (value) {
                              if (value != _passwordController.text) {
                                return 'Las contraseñas no coinciden';
                              }
                              return null;
                            }),
                            SizedBox(height: fieldSpacing * 2),
                            Center(
                              child: _buildButton(
                                constraints,
                                'Regístrate',
                                _isLoading ? null : _registrar,
                                isTablet ? 0.4 : 0.8,
                                fontSize,
                              ),
                            ),
                            if (_errorMessage.isNotEmpty)
                              Padding(
                                padding: EdgeInsets.only(top: 10),
                                child: Text(
                                  _errorMessage,
                                  style: TextStyle(color: Colors.red),
                                ),
                              ),
                          ],
                        ),
                        SizedBox(height: fieldSpacing * 2),
                        Image.asset(
                          'assets/images/logo_citt.png',
                          width:
                              constraints.maxWidth * (isTablet ? 0.15 : 0.25),
                          height:
                              constraints.maxWidth * (isTablet ? 0.15 : 0.25),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
    BoxConstraints constraints,
    String hintText,
    double fontSize, {
    bool isPassword = false,
    required TextEditingController controller,
    String? Function(String?)? validator,
    List<TextInputFormatter>? inputFormatters, // Agrega este parámetro opcional
  }) {
    return TextFormField(
      controller: controller,
      obscureText: isPassword,
      validator: validator,
      inputFormatters: inputFormatters, // Aplica los filtros
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        hintText: hintText,
        hintStyle: TextStyle(fontSize: constraints.maxWidth * fontSize),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(constraints.maxWidth * 0.02)),
      ),
    );
  }

  Widget _buildButton(
    BoxConstraints constraints,
    String text,
    VoidCallback? onPressed,
    double width,
    double fontSize,
  ) {
    return SizedBox(
      width: constraints.maxWidth * width,
      height: constraints.maxHeight * 0.06,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(constraints.maxWidth * 0.02),
          ),
        ),
        child: _isLoading
            ? CircularProgressIndicator(color: Colors.white)
            : Text(
                text,
                style: TextStyle(fontSize: constraints.maxWidth * fontSize),
              ),
      ),
    );
  }
}
