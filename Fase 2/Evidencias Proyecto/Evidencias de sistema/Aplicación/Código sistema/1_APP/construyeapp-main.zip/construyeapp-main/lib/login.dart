// lib/login.dart
import 'package:flutter/material.dart';
import 'login_logic.dart';
import 'main.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final LoginLogic _loginLogic = LoginLogic();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        color: primaryColor,
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final isTablet = constraints.maxWidth >= 600;
              final double logoWidth = isTablet ? 0.5 : 0.8;
              final double textFieldWidth = isTablet ? 0.6 : 0.8;
              final double buttonWidth = isTablet ? 0.4 : 0.8;
              final double fontSize = isTablet ? 0.025 : 0.04;

              return SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).viewInsets.bottom),
                  child: ConstrainedBox(
                    constraints:
                        BoxConstraints(minHeight: constraints.maxHeight),
                    child: IntrinsicHeight(
                      child: Padding(
                        padding: EdgeInsets.all(
                            constraints.maxWidth * (isTablet ? 0.2 : 0.1)),
                        child: Form(
                          key: _loginLogic.formKey,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Image.asset(
                                'assets/images/logo_cchc.png',
                                width: constraints.maxWidth * logoWidth,
                              ),
                              SizedBox(height: constraints.maxHeight * 0.05),
                              Expanded(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    _buildTextField(
                                      constraints,
                                      'Email o RUT',
                                      textFieldWidth,
                                      fontSize,
                                      controller:
                                          _loginLogic.identifierController,
                                      validator: _loginLogic.validateIdentifier,
                                    ),
                                    SizedBox(
                                        height: constraints.maxHeight * 0.02),
                                    _buildTextField(
                                      constraints,
                                      'Contraseña',
                                      textFieldWidth,
                                      fontSize,
                                      isPassword: true,
                                      controller:
                                          _loginLogic.passwordController,
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Por favor ingrese su contraseña';
                                        }
                                        return null;
                                      },
                                    ),
                                    SizedBox(
                                        height: constraints.maxHeight * 0.04),
                                    _buildButton(
                                      constraints,
                                      'Iniciar Sesión',
                                      _loginLogic.isLoading
                                          ? null
                                          : () async {
                                              setState(
                                                  () {}); // Actualizar UI inmediatamente cuando isLoading cambie
                                              await _loginLogic.login(context);
                                              setState(
                                                  () {}); // Actualizar UI cuando termine el login
                                            },
                                      buttonWidth,
                                      fontSize,
                                    ),
                                    if (_loginLogic.errorMessage.isNotEmpty)
                                      Padding(
                                        padding: EdgeInsets.only(top: 10),
                                        child: Text(
                                          _loginLogic.errorMessage,
                                          style: TextStyle(color: Colors.red),
                                        ),
                                      ),
                                    TextButton(
                                      onPressed: () {},
                                      child: Text(
                                        '¿Olvidaste tu contraseña?',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize:
                                              constraints.maxWidth * fontSize,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: constraints.maxHeight * 0.05),
                              Image.asset(
                                'assets/images/logo_citt.png',
                                width: constraints.maxWidth *
                                    (isTablet ? 0.15 : 0.25),
                                height: constraints.maxWidth *
                                    (isTablet ? 0.15 : 0.25),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
    BoxConstraints constraints,
    String hintText,
    double width,
    double fontSize, {
    bool isPassword = false,
    required TextEditingController controller,
    String? Function(String?)? validator,
  }) {
    return SizedBox(
      width: constraints.maxWidth * width,
      child: TextFormField(
        controller: controller,
        obscureText: isPassword,
        validator: validator,
        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.white,
          hintText: hintText,
          hintStyle: TextStyle(fontSize: constraints.maxWidth * fontSize),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(constraints.maxWidth * 0.02),
          ),
        ),
      ),
    );
  }

  Widget _buildButton(
    BoxConstraints constraints,
    String text,
    VoidCallback? onPressed,
    double width,
    double fontSize,
  ) {
    return SizedBox(
      width: constraints.maxWidth * width,
      height: constraints.maxHeight * 0.06,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(constraints.maxWidth * 0.02),
          ),
        ),
        child: _loginLogic.isLoading
            ? CircularProgressIndicator(color: Colors.white)
            : Text(
                text,
                style: TextStyle(fontSize: constraints.maxWidth * fontSize),
              ),
      ),
    );
  }
}
