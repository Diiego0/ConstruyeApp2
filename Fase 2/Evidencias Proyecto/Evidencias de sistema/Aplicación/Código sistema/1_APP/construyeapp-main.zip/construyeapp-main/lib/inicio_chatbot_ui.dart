// lib/inicio_chatbot_ui.dart
import 'package:construyeapp/widgets/event_tracker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'inicio_chatbot_logic.dart';
import 'sidebar_widget.dart';
import 'widgets/typewriter_animated_text.dart';
import 'widgets/chat_message_bubble.dart';
import 'main.dart';
import 'dart:math' as math;
import 'widgets/quick_questions_service.dart';

class ConstructionBackgroundPainter extends CustomPainter {
  final Color iconColor;

  ConstructionBackgroundPainter({required this.iconColor});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = iconColor.withOpacity(0.1)
      ..style = PaintingStyle.fill;

    List<IconData> constructionIcons = [
      Icons.construction,
      Icons.home_repair_service,
      Icons.architecture,
      Icons.engineering,
      Icons.handyman,
      Icons.build,
      Icons.apartment,
      Icons.precision_manufacturing,
    ];

    double iconSize = size.width * 0.05;
    double spacing = size.width * 0.11;
    double yOffset = spacing / 2;

    // Draw main icons
    for (double y = -yOffset; y < size.height + yOffset; y += spacing) {
      bool oddRow = (y / spacing).round().isOdd;
      double xStart = oddRow ? 0 : -spacing / 2;
      
      for (double x = xStart; x < size.width + spacing / 2; x += spacing) {
        int iconIndex = ((x / spacing).round() + (y / spacing).round()) % constructionIcons.length;
        IconData icon = constructionIcons[iconIndex];

        _drawIcon(canvas, Offset(x, y), icon, iconSize, paint);
      }
    }

    // Draw small elements
    _drawSmallElements(canvas, size, paint);
  }

  void _drawIcon(Canvas canvas, Offset center, IconData icon, double size, Paint paint) {
    TextPainter textPainter = TextPainter(
      text: TextSpan(
        text: String.fromCharCode(icon.codePoint),
        style: TextStyle(
          fontSize: size,
          fontFamily: icon.fontFamily,
          color: paint.color,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    textPainter.layout();
    textPainter.paint(canvas, Offset(center.dx - size / 2, center.dy - size / 2));
  }

  void _drawSmallElements(Canvas canvas, Size size, Paint paint) {
    final random = math.Random(0);
    int smallElementsCount = (size.width * size.height / 250).round();

    for (int i = 0; i < smallElementsCount; i++) {
      double x = random.nextDouble() * size.width;
      double y = random.nextDouble() * size.height;
      
      int elementType = random.nextInt(3);
      switch (elementType) {
        case 0:
          // Draw dot
          canvas.drawCircle(Offset(x, y), 1, paint);
          break;
        case 1:
          // Draw small cross
          canvas.drawLine(Offset(x - 2, y - 2), Offset(x + 2, y + 2), paint);
          canvas.drawLine(Offset(x + 2, y - 2), Offset(x - 2, y + 2), paint);
          break;
        case 2:
          // Draw small square
          canvas.drawRect(Rect.fromCenter(center: Offset(x, y), width: 3, height: 3), paint);
          break;
      }
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}


class InicioChatBot extends StatefulWidget {
    final String? chatId;
    final InicioChatBotLogic? chatLogic;
    final bool initialChatMode;
    final bool shouldContinueConversation;    
  const InicioChatBot({super.key, this.chatLogic, this.chatId, this.initialChatMode = false, this.shouldContinueConversation = false,});

  @override
  State<InicioChatBot> createState() => _CopilotChatState();
}

class _CopilotChatState extends State<InicioChatBot>
    with SingleTickerProviderStateMixin {
  final QuickQuestionsService _quickQuestionsService = QuickQuestionsService();
List<QuickQuestion> _quickQuestions = QuickQuestionsService.defaultQuestions;
  bool _isChatbotReady = false;
  bool _isFirstTime = true;
  int _previousMessageCount = 0;
  bool _shouldScroll = false;
  bool _shouldScrollOnEnterChat = false;
  late InicioChatBotLogic _chatLogic;
  final ScrollController _scrollController = ScrollController();
  final TextEditingController _controller = TextEditingController();
  late AnimationController _animationController;
  late Animation<double> _animation;
  List<ChatMessage> _messages = [];
  bool _isWaitingForResponse = false;
  // ignore: unused_field
  bool _isSidebarExpanded = false;
  bool _isChatMode = false;
  final Color primaryColor = const Color.fromARGB(255, 23, 112, 192); // Tu color primario
  bool _isAlertShowing = false;

  void _showChatClosedAlert() {
    if (_isAlertShowing) return;
    tracker.capture(
    eventName: 'Chat_Inactivity_Alert',
    properties: {
      'message_count': _messages.length,
      'conversation_duration': DateTime.now(),
    },
  );
    setState(() {
      _isAlertShowing = true;
    });

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Chat cerrado'),
          content: const Text('El chat se ha cerrado debido a inactividad. Se ha guardado automáticamente.'),
          actions: <Widget>[
            TextButton(
              child: const Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
                setState(() {
                  _isAlertShowing = false;
                });
              },
            ),
          ],
        );
      },
    ).then((_) {
      // En caso de que el diálogo se cierre de otra manera (por ejemplo, tocando fuera de él)
      setState(() {
        _isAlertShowing = false;
      });
    });
  }
  Future<void> _loadQuestions() async {
    final questions = await _quickQuestionsService.getQuestions();
    if (mounted) {
      setState(() {
        _quickQuestions = questions;
      });
      // Para debug
      if (kDebugMode) {
        print('Preguntas cargadas de la API:');
      }
      for (var q in questions) {
        if (kDebugMode) {
          print('ID: ${q.id}, Pregunta: ${q.question}');
        }
      }
    }
  }
  
@override
void initState() {
  super.initState();
  _loadQuestions();
  _isChatMode = widget.initialChatMode;

  if (kDebugMode) {
    print("initState llamado en _CopilotChatState");
    print("chatId recibido: ${widget.chatId}");
  }

  // Suscribirse al Stream de eventos del chat
  chatEventController.stream.listen((event) {
    if (event == 'chat_closed' && !_isAlertShowing) {
      if (mounted) {  // Verificar si el widget está montado
        setState(() {
          _isChatMode = false;
          _messages.clear();
        });
        _showChatClosedAlert();
      }
    }
  });

  _chatLogic = InicioChatBotLogic(
    onMessagesUpdated: (messages) {
      setState(() {
        _messages = messages;
        if (_messages.length > _previousMessageCount) {
          _shouldScroll = true;
        }
        _previousMessageCount = _messages.length;
        _scrollToBottom();
      });
    },
    onWaitingForResponseChanged: (isWaiting) {
      setState(() {
        _isWaitingForResponse = isWaiting;
      });
    },
    onChatClosed: () {
      if (!_isAlertShowing) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          setState(() {
            _isChatMode = false;
          });
          _showChatClosedAlert();
        });
      }
    },
  );

  _initializeChat();
  _animationController = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 300),
  );
  _animation = CurvedAnimation(
    parent: _animationController,
    curve: Curves.easeInOut,
  );

  _scrollController.addListener(() {
    if (_scrollController.position.maxScrollExtent > _scrollController.offset &&
        (_scrollController.position.maxScrollExtent - _scrollController.offset) < 100) {
      _scrollToBottom();
    }
  });
  _checkFirstTime();
}

Future<void> _initializeChat() async {
  if (kDebugMode) {
    print("_initializeChat llamado");
  }
  if (widget.chatId != null) {
    if (kDebugMode) {
      print("Cargando chat desde historial con ID: ${widget.chatId}");
    }
    await _loadChatFromHistory(widget.chatId!);
    
    if (widget.shouldContinueConversation) {
      if (kDebugMode) {
        print("Llamando a continuarConversacion con chatId: ${widget.chatId}");
      }
      await _chatLogic.continuarConversacion(widget.chatId!);
    } else {
      if (kDebugMode) {
        print("No se llamó a continuarConversacion");
      }
    }
  } else {
    if (kDebugMode) {
      print("Inicializando nuevo chat");
    }
    await _chatLogic.initialize();
  }

  setState(() {
    _isFirstTime = false;
    _isChatbotReady = true;  // Set this to true when initialization is complete
  });

  if (kDebugMode) {
    print("_isFirstTime establecido a false");
    print("Chatbot está listo");
  }
}

  Future<void> _loadChatFromHistory(String chatId) async {
    if (kDebugMode) {
      print("_loadChatFromHistory llamado con ID: $chatId");
    }
    await _chatLogic.loadChatFromHistory(chatId);
    setState(() {
      _isFirstTime = false;
    });
    if (kDebugMode) {
      print("Chat cargado desde historial, mensajes: ${_chatLogic.messages.length}");
    }
  }


  Future<void> _checkFirstTime() async {
    final prefs = await SharedPreferences.getInstance();
    _isFirstTime = prefs.getBool('first_time') ?? true;
    if (_isFirstTime) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showFirstTimeDialog();
      });
    }
  }


Future<void> _showFirstTimeDialog() async {
  bool hasChildren = false;
  bool isEnrolled = false;
  int numberOfChildren = 1;
    tracker.capture(
    eventName: 'First_Time_Dialog_Shown',
    properties: {'timestamp': DateTime.now().toIso8601String()},
  );
  await showDialog(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext context) {
      return StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: const Text('Bienvenido a Construye++'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Por favor, responde estas preguntas:'),
                CheckboxListTile(
                  title: const Text('¿Tienes hijos?'),
                  value: hasChildren,
                  onChanged: (value) {
                    setState(() {
                      hasChildren = value!;
                    });
                  },
                ),
                CheckboxListTile(
                  title: const Text('¿Estás inscrito en algún beneficio de la CChC?'),
                  value: isEnrolled,
                  onChanged: (value) {
                    setState(() {
                      isEnrolled = value!;
                    });
                  },
                ),
              ],
            ),
            actions: [
              TextButton(
                style: TextButton.styleFrom(
                  foregroundColor: Theme.of(context).primaryColor,
                ),
                child: const Text('Confirmar'),
                onPressed: () async {
                  Navigator.of(context).pop();
                  // Save the responses and mark first time as false
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setBool('first_time', false);
                  await prefs.setBool('has_children', hasChildren);
                  await prefs.setInt('number_of_children', numberOfChildren);
                  await prefs.setBool('is_enrolled', isEnrolled);
                  tracker.capture(
                    eventName: 'User_Profile_Created',
                    properties: {
                      'has_children': hasChildren,
                      'number_of_children': hasChildren ? numberOfChildren : 0,
                      'is_enrolled': isEnrolled,
                    },
                  );
                  _showProfileMessage();
                },
              ),
            ],
          );
        },
      );
    },
  );
}



void _showProfileMessage() {
  const Color primaryColor = Color.fromARGB(255, 23, 112, 192);

  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.rectangle,
            borderRadius: BorderRadius.circular(20),
            boxShadow: const [
              BoxShadow(
                color: Colors.black26,
                blurRadius: 10.0,
                offset: Offset(0.0, 10.0),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const Icon(
                Icons.info_outline,
                color: primaryColor,
                size: 50,
              ),
              const SizedBox(height: 16),
              const Text(
                'Información guardada',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                  color: primaryColor,
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Gracias por proporcionar tu información. Puedes modificarla más tarde en tu perfil.',
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Align(
                alignment: Alignment.bottomRight,
                child: TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: const Text(
                    'Entendido',
                    style: TextStyle(fontSize: 18, color: primaryColor),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}



  @override
  void dispose() {
    _chatLogic.dispose();
    _controller.dispose();
    _animationController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  //función para el modo oscuro/claro, FALTA ATENUAR CON ANIMACIÓN
  void _toggleTheme() {
    setState(() {
      isDarkMode = !isDarkMode;
      
      tracker.capture(
        eventName: 'Theme_Changed',
        properties: {'dark_mode': isDarkMode},
      );
    });
  }

  //función para la sidebar
  void _toggleSidebar() {
    if (_animationController.status == AnimationStatus.completed) {
      _isSidebarExpanded = true;
      _animationController.reverse();
      
      tracker.capture(
        eventName: 'Sidebar_Closed',
        properties: {'method': 'animation'},
      );
    } else {
      _isSidebarExpanded = false;
      _animationController.forward();
      
      tracker.capture(
        eventName: 'Sidebar_Opened',
        properties: {'method': 'animation'},
      );
    }
  }

  //función cambio de body a modo chat / inicio
  void _toggleChatMode() {
    // Solo verificar mensajes si es un cambio manual (no desde _handleSubmitted)
    if (!_isChatMode && _messages.isEmpty && !_isWaitingForResponse) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Inicia una conversación usando las consultas rápidas'),
          duration: Duration(seconds: 2),
        ),
      );
    tracker.capture(
      eventName: 'Empty_Chat_Mode_Attempt',
      properties: {'has_messages': false},
    );
      return;
    }

    setState(() {
      _isChatMode = !_isChatMode;
      if (_isChatMode) {
        _shouldScrollOnEnterChat = true;
      }
    tracker.capture(
      eventName: 'Mode_Changed',
      properties: {
        'new_mode': _isChatMode ? 'chat' : 'home',
        'message_count': _messages.length,
      },
    );
    });

    if (_isChatMode) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToBottom();
      });
    }
  }
  //función mensajes enviados por el usuario
  void _handleSubmitted(String text) {
    if (!_isChatbotReady || text.trim().isEmpty) return;
    _controller.clear();

    // Para el primer mensaje, forzamos el cambio a modo chat sin verificar _messages
    if (!_isChatMode) {
      setState(() {
        _isChatMode = true;
        _shouldScrollOnEnterChat = true;
      });
    }

    // Enviar el mensaje
    _chatLogic.sendMessage(text);

    // Scroll al fondo si es necesario
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });
  }

void _consultasRapidas(String text) {
  tracker.capture(
    eventName: 'Quick_Question_Selected',
    properties: {
      'question': text,
      'timestamp': DateTime.now().toIso8601String(),
    },
  );
  
  _handleSubmitted(text);
}

//----------------------------------------INTERFAZ INICIO CHAT
  @override
  Widget build(BuildContext context) {
    Color backgroundColorTheme =
        isDarkMode ? primaryColorDarkMode : primaryColor;

    //popscope se usa para la tecla volver atrás
    //si está en chat, lo devuelve al panel inicio
    //si está en inicio, le pregunta si desea salir
    return PopScope(
      canPop: false,
      // ignore: deprecated_member_use
      onPopInvoked: (didPop) async {
        if (_isWaitingForResponse) {
          return;
        }
        if (_isChatMode) {
          WidgetsBinding.instance
              .addPostFrameCallback((_) => _scrollToBottom());
          _toggleChatMode();
        } else {
          final shouldPop = await showDialog<bool>(
            context: context,
            builder: (context) {
              return AlertDialog(
                title: const Text('¿Quieres salir de la app?'),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    child: const Text('Cancelar'),
                  ),
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(true),
                    child: const Text('Salir'),
                  ),
                ],
              );
            },
          );
          if (shouldPop ?? false) {
            SystemNavigator.pop();
          }
        }
      },
      child: GestureDetector(
        onTap: () {
          // Esto ocultará el teclado cuando se toque fuera del campo de texto
          FocusScope.of(context).unfocus();
        },
        child: Scaffold(
          //appbar
          appBar: AppBar(
            title: const Text('Construye++',
                style: TextStyle(color: Colors.white)),
            backgroundColor: backgroundColorTheme,
            leading: IconButton(
              icon: const Icon(Icons.menu, color: Colors.white),
              onPressed: _isWaitingForResponse ? null : _toggleSidebar,
            ),
            actions: [
              IconButton(
                icon: Icon(isDarkMode ? Icons.dark_mode : Icons.light_mode,
                    color: Colors.white),
                onPressed: _toggleTheme,
              ),
            ],
            centerTitle: true,
          ),
          body: Stack(
            children: [
              //body, footer, sidebarAction
              _isChatMode
                  ? _buildMainChatContent(context)
                  : _buildMainBodyContent(context),
              _buildFootContent(context),
              _buildSideBarAction(context),
            ],
          ),
        ),
      ),
    );
  }

//----------------------------------------INTERFAZ CHAT BODY
  Widget _buildSideBarAction(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return Stack(
          children: [
            // Área para detectar el arrastre desde el borde izquierdo
            Positioned(
              left: 0,
              top: 0,
              bottom: 0,
              width:
                  60, // Ancho del área sensible al toque en el borde izquierdo
              child: GestureDetector(
                onHorizontalDragUpdate: (details) {
                  double delta = details.primaryDelta! / 250;
                  _animationController.value =
                      (_animationController.value + delta).clamp(0.0, 1.0);
                },
                onHorizontalDragEnd: (details) {
                  if (_animationController.value > 0.1) {
                    _animationController.forward();
                  } else {
                    _animationController.reverse();
                  }
                },
              ),
            ),
            // Fondo oscuro
            if (_animation.value > 0)
              Positioned.fill(
                child: GestureDetector(
                  onTap: _toggleSidebar,
                  child: Container(
                    color: Colors.black54.withOpacity(0.5 * _animation.value),
                  ),
                ),
              ),
            // Barra lateral
            Positioned(
              left: -250 * (1 - _animation.value),
              top: 0,
              bottom: 0,
              width: 250,
              child: GestureDetector(
                onHorizontalDragUpdate: (details) {
                  double delta = details.primaryDelta! / 250;
                  _animationController.value =
                      (_animationController.value + delta).clamp(0.0, 1.0);
                },
                onHorizontalDragEnd: (details) {
                  if (_animationController.value > 0.9) {
                    _animationController.forward();
                  } else {
                    _animationController.reverse();
                  }
                },
                child: SidebarWidget(
                  toggleSidebar: _toggleSidebar,
                  toggleChatMode: _toggleChatMode,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

//----------------------------------------INTERFAZ CHAT BODY
//este es el centro del panel chat donde van los mensajes
Widget _buildMainChatContent(BuildContext context) {
  Color backgroundColorTheme =
      isDarkMode ? primaryColorDarkMode : primaryColor;
  return Container(
    color: backgroundColorTheme,
    child: CustomPaint(
      painter: ConstructionBackgroundPainter(
        iconColor: Colors.white,
      ),
      child: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                return MessageBubble(
                  message: _messages[index],
                  isLastMessage: index == _messages.length - 1,
                );
              },
            ),
          ),
          const SizedBox(height: 70),
        ],
      ),
    ),
  );
}

//----------------------------------------INTERFAZ INICIO BODY
//este es el centro del panel inicio donde el bot saluda al usuario
  Widget _buildMainBodyContent(BuildContext context) {
    Color backgroundColorTheme =
        isDarkMode ? primaryColorDarkMode : primaryColor;
    return Container(
      color: backgroundColorTheme,
      child: Column(
        children: [
          const SizedBox(height: 5),
          Stack(
            alignment: Alignment.center,
            children: [
              SizedBox(
                width: 300,
                height: 210,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      width: 160,
                      height: 160,
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                      child: const Center(
                        child: Icon(
                          Icons.smart_toy,
                          size: 100,
                          color: Colors.grey,
                        ),
                      ),
                    ),
                    Positioned(
                      top: 0,
                      right: 0,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child:
                            const TypewriterAnimatedText('¡Hola,\nbienvenido!'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 15),
          const Text(
            'Consultas rápidas',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 15),
          Expanded(
            child: LayoutBuilder(
              builder: (context, constraints) {
                return SingleChildScrollView(
                  child: Center(
                    child: ConstrainedBox(
                      constraints:
                          BoxConstraints(maxWidth: constraints.maxWidth * 0.7),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: _quickQuestions.map((question) {
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: _buildButton(context, question.question),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

//----------------------------------------INTERFAZ INICIO CHAT BOTÓN
//widget botón reciclable para consultas rápidas
  Widget _buildButton(BuildContext context, String text) {
    return ElevatedButton(
      onPressed: () => _consultasRapidas(text),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        elevation: 2,
        padding: const EdgeInsets.symmetric(vertical: 10),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25),
        ),
      ),
      child: Text(
        text,
        style: const TextStyle(color: Colors.black87, fontSize: 16),
      ),
    );
  }

//----------------------------------------INTERFAZ INICIO CHAT FOOT
//campo de texto e ícono botón para escribir mandar mensajes al bot
  Widget _buildFootContent(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_isWaitingForResponse || !_isChatbotReady)
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: CircularProgressIndicator(),
            ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              style: const TextStyle(color: Colors.black),
              controller: _controller,
              onSubmitted: _isChatbotReady ? _handleSubmitted : null,
              decoration: InputDecoration(
                fillColor: Colors.white,
                filled: true,
                hintText: !_isChatbotReady
                    ? 'Cargando chatbot...'
                    : _isWaitingForResponse
                        ? 'Esperando respuesta...'
                        : 'Escribe un mensaje...',
                hintStyle: const TextStyle(color: Colors.black45),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.send, color: Colors.black),
                  onPressed: (_isChatbotReady && !_isWaitingForResponse)
                      ? () => _handleSubmitted(_controller.text)
                      : null,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              ),
              enabled: _isChatbotReady && !_isWaitingForResponse,
            ),
          ),
        ],
      ),
    );
  }

  void _scrollToBottom() {
    if (_shouldScroll || _shouldScrollOnEnterChat) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scrollController.hasClients) {
          _scrollController
              .animateTo(
            _scrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          )
              .then((_) {
            setState(() {
              _shouldScroll = false;
              _shouldScrollOnEnterChat = false;
            });
          });
        }
      });
    }
  }
}
