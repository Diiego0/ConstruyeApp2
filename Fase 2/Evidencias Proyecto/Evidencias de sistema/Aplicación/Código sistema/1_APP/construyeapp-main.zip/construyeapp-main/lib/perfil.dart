// lib/perfil.dart
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';
import 'main.dart';

class ChildData {
  final TextEditingController nameController;
  final TextEditingController birthdateController;
  //String sex;
  bool isStudent = false;

  ChildData({String name = '', this.isStudent = false})
      : nameController = TextEditingController(text: name),
        birthdateController = TextEditingController();
}

//-----------------------------------PERFIL DE USUARIO
class Perfil extends StatefulWidget {
  const Perfil({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _UserProfileScreenState createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<Perfil> {
  //Variables datos de usuario
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _rutController = TextEditingController();
  final TextEditingController _numberController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _companyController = TextEditingController();
  final TextEditingController _childrenCountController =
      TextEditingController();
  int _childrenCount = 0;
  //variables ajustes UI
  static const double kTextFieldHeight = 48.0;
  static const double kTextFieldFontSize = 14.0;
  static const double kLabelFontSize = 12.0;
  static const double kIconSize = 20.0;
  static const EdgeInsets kTextFieldPadding =
      EdgeInsets.symmetric(vertical: 8.0, horizontal: 12.0);
  static const double kSaveButtonHeight = 48.0;
  static const double kSaveButtonFontSize = 16.0;
  static const double kSaveButtonWidth = 0.5; // 50% del ancho de la pantalla
  static const double kProfileImageSize = 120.0;
  static const double kProfileCardPadding = 16.0;
  //variables
  File? _image;
  final picker = ImagePicker();
  List<ChildData> _childrenData = [];

  Future getImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
      }
    });
  }

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Perfil',
            style: TextStyle(color: isDarkMode ? Colors.white : Colors.white)),
        backgroundColor: isDarkMode ? primaryColorDarkMode : primaryColor,
        iconTheme:
            IconThemeData(color: isDarkMode ? Colors.white : Colors.white),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              isDarkMode ? primaryColorDarkMode : primaryColor,
              isDarkMode ? Colors.grey[800]! : Colors.blue[500]!,
            ],
          ),
        ),
        child: SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: MediaQuery.of(context).size.height -
                  AppBar().preferredSize.height -
                  MediaQuery.of(context).padding.top,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _buildProfileImageCard(),
                        const SizedBox(height: 2),
                        _buildProfileCard(),
                        const SizedBox(height: 2),
                        _buildChildrenSection(),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(2),
                  child: _buildSaveButton(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  //-----------UI IMAGEN DE USUARIO Y CARGA DE IMAGEN
  Widget _buildProfileImageCard() {
    return Card(
      elevation: 4,
      color: isDarkMode ? Colors.grey[800] : Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: Padding(
        padding: const EdgeInsets.all(kProfileCardPadding),
        child: Column(
          children: [
            CircleAvatar(
              radius: kProfileImageSize / 2,
              backgroundColor: isDarkMode ? Colors.grey[600] : Colors.grey[300],
              backgroundImage: _image != null ? FileImage(_image!) : null,
              child: _image == null
                  ? Icon(
                      Icons.person,
                      size: kProfileImageSize / 2,
                      color: isDarkMode ? Colors.grey[400] : Colors.grey[600],
                    )
                  : null,
            ),
            const SizedBox(height: 8),
            Center(
              child: SizedBox(
                height: kSaveButtonHeight,
                width: MediaQuery.of(context).size.width * kSaveButtonWidth,
                child: ElevatedButton.icon(
                  onPressed: getImage,
                  icon: const Icon(Icons.camera_alt, color: Colors.white),
                  label: const Text('Cambiar foto',
                      style: TextStyle(color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        isDarkMode ? Colors.grey[700] : primaryColor,
                    foregroundColor: Colors.white,
                    elevation: 2,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  //-----------UI DATOS BÁSICOS
  Widget _buildProfileCard() {
    return Card(
      elevation: 4,
      color: isDarkMode ? Colors.grey[800] : Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _buildTextField(_nameController, 'Nombre', Icons.person),
            _buildTextField(
                _lastNameController, 'Apellido', Icons.person_outline),
            _buildTextField(_rutController, 'RUT', Icons.credit_card),
            _buildTextField(_numberController, 'Número Teléfono', Icons.phone),
            _buildTextField(_emailController, 'Email', Icons.email),
            _buildTextField(_addressController, 'Dirección', Icons.home),
            _buildTextField(_companyController, 'Empresa', Icons.business),
            _buildTextField(
                _childrenCountController, 'Cantidad de hijos', Icons.child_care,
                keyboardType: TextInputType.number,
                onChanged: _onChildrenCountChanged),
          ],
        ),
      ),
    );
  }

  Future<void> _selectDate(BuildContext context, int index) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
      locale: const Locale('es', 'ES'), // Para mostrar el calendario en español
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: isDarkMode ? Colors.blue[300]! : primaryColor,
              onPrimary: Colors.white,
              surface: isDarkMode ? Colors.grey[800]! : Colors.white,
              onSurface: isDarkMode ? Colors.white : Colors.black,
            ),
            dialogBackgroundColor: isDarkMode ? Colors.grey[800] : Colors.white,
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        // Formatear la fecha como dd/mm/yyyy
        _childrenData[index].birthdateController.text =
            "${picked.day.toString().padLeft(2, '0')}/"
            "${picked.month.toString().padLeft(2, '0')}/"
            "${picked.year.toString()}";
      });
    }
  }

  Widget _buildChildDateField(TextEditingController controller, int index) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: SizedBox(
        height: kTextFieldHeight,
        child: TextField(
          controller: controller,
          readOnly: true, // Hace el campo de solo lectura
          style: TextStyle(
            fontSize: kTextFieldFontSize,
            color: isDarkMode ? Colors.white : Colors.black,
          ),
          decoration: InputDecoration(
            labelText: 'Fecha de nacimiento',
            labelStyle: TextStyle(
              fontSize: kLabelFontSize,
              color: isDarkMode ? Colors.white70 : Colors.black54,
            ),
            prefixIcon: Icon(
              Icons.calendar_today,
              size: kIconSize,
              color: isDarkMode ? Colors.white70 : Colors.black54,
            ),
            suffixIcon: Icon(
              Icons.arrow_drop_down,
              size: kIconSize,
              color: isDarkMode ? Colors.white70 : Colors.black54,
            ),
            filled: true,
            fillColor: isDarkMode ? Colors.grey[700] : Colors.grey[100],
            contentPadding: kTextFieldPadding,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide.none,
            ),
            hintText: 'DD/MM/YYYY',
          ),
          onTap: () => _selectDate(context, index),
        ),
      ),
    );
  }

  //-----------UI HIJOS
  Widget _buildChildrenSection() {
    return Column(
      children: List.generate(_childrenCount, (index) {
        return Padding(
          padding: const EdgeInsets.only(top: 16.0), // Más espacio arriba
          child: Card(
            elevation: 4,
            color: isDarkMode ? Colors.grey[700] : Colors.blue[50],
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            margin: const EdgeInsets.only(bottom: 8),
            child: Column(
              children: [
                // Encabezado para cada hijo
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: isDarkMode ? Colors.grey[800] : Colors.blue[100],
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(8),
                      topRight: Radius.circular(8),
                    ),
                  ),
                  child: Text(
                    'Hijo ${index + 1}',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: isDarkMode ? Colors.white : Colors.blue[800],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildTextField(
                        _childrenData[index].nameController,
                        'Nombre completo',
                        Icons.person,
                      ),
                      const SizedBox(height: 8),
                      _buildChildDateField(
                          _childrenData[index].birthdateController, index),
                      const SizedBox(height: 8),
                      SwitchListTile(
                        title: Text('¿Es estudiante?',
                            style: TextStyle(
                                color:
                                    isDarkMode ? Colors.white : Colors.black)),
                        value: _childrenData[index].isStudent,
                        onChanged: (bool value) {
                          setState(() {
                            _childrenData[index].isStudent = value;
                          });
                        },
                        activeColor:
                            isDarkMode ? Colors.blue[300] : Colors.blue,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }

  //-----------UI CAMPO DE TEXTO
  Widget _buildTextField(
    TextEditingController controller,
    String label,
    IconData icon, {
    TextInputType? keyboardType,
    Function(String)? onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: SizedBox(
        height: kTextFieldHeight,
        child: TextField(
          controller: controller,
          keyboardType: keyboardType,
          onChanged: onChanged,
          style: TextStyle(
              fontSize: kTextFieldFontSize,
              color: isDarkMode ? Colors.white : Colors.black),
          decoration: InputDecoration(
            labelText: label,
            labelStyle: TextStyle(
                fontSize: kLabelFontSize,
                color: isDarkMode ? Colors.white70 : Colors.black54),
            prefixIcon: Icon(icon,
                size: kIconSize,
                color: isDarkMode ? Colors.white70 : Colors.black54),
            filled: true,
            fillColor: isDarkMode ? Colors.grey[700] : Colors.grey[100],
            contentPadding: kTextFieldPadding,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide.none,
            ),
          ),
        ),
      ),
    );
  }

  //-----------UI BOTÓN GUARDAR
  Widget _buildSaveButton() {
    return Center(
      child: SizedBox(
        height: kSaveButtonHeight,
        width: MediaQuery.of(context).size.width * kSaveButtonWidth,
        child: ElevatedButton.icon(
          onPressed: _saveUserData,
          icon: const Icon(Icons.save),
          label: const Text('Guardar',
              style: TextStyle(fontSize: kSaveButtonFontSize)),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.white,
            foregroundColor: Colors.black,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
      ),
    );
  }

  //-----------Función el conteo de hijos
  void _onChildrenCountChanged(String value) {
    int newCount = int.tryParse(value) ?? 0;
    setState(() {
      // Guardar los datos existentes
      List<ChildData> existingData = List.from(_childrenData);

      // Actualizar el contador
      _childrenCount = newCount;

      // Si aumentamos la cantidad de hijos
      if (_childrenData.length < newCount) {
        // Mantener los datos existentes y agregar nuevos espacios
        while (_childrenData.length < newCount) {
          _childrenData.add(ChildData());
        }
      } else if (_childrenData.length > newCount) {
        // Si reducimos la cantidad, guardamos temporalmente los datos
        _childrenData = existingData.sublist(0, newCount);

        // Opcional: Guardar los datos eliminados por si el usuario se equivocó
        List<ChildData> removedChildren = existingData.sublist(newCount);
        // Podrías mostrar un snackbar para confirmar la eliminación
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Se eliminaron ${removedChildren.length} registros'),
            action: SnackBarAction(
              label: 'Deshacer',
              onPressed: () {
                setState(() {
                  _childrenCount = existingData.length;
                  _childrenData = existingData;
                  _childrenCountController.text =
                      existingData.length.toString();
                });
              },
            ),
            duration: const Duration(seconds: 5),
          ),
        );
      }
    });
  }

  //-----------Función para guardar datos de usuario
  void _saveUserData() async {
    final prefs = await SharedPreferences.getInstance();

    // Guardar datos del perfil
    await prefs.setString('name', _nameController.text);
    await prefs.setString('lastName', _lastNameController.text);
    await prefs.setString('rut', _rutController.text);
    await prefs.setString('email', _emailController.text);
    await prefs.setString('number', _numberController.text);
    await prefs.setString('address', _addressController.text);
    await prefs.setString('company', _companyController.text);
    await prefs.setInt('childrenCount', _childrenCount);

    // Guardar datos de los hijos
    for (int i = 0; i < _childrenCount; i++) {
      await prefs.setString(
          'childName$i', _childrenData[i].nameController.text);
      await prefs.setString(
          'childBirthdate$i', _childrenData[i].birthdateController.text);
      await prefs.setBool('childIsStudent$i', _childrenData[i].isStudent);
    }

    // Guardar la ruta de la imagen si existe
    if (_image != null) {
      await prefs.setString('profileImagePath', _image!.path);
    }

    // Mostrar un mensaje de éxito
    // ignore: use_build_context_synchronously
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Datos guardados con éxito')),
    );
  }

  //-----------Función para cargar datos de usuario guardados
  void _loadUserData() async {
    final prefs = await SharedPreferences.getInstance();

    setState(() {
      _nameController.text = prefs.getString('name') ?? '';
      _lastNameController.text = prefs.getString('lastName') ?? '';
      _rutController.text = prefs.getString('rut') ?? '';
      _emailController.text = prefs.getString('email') ?? '';
      _numberController.text = prefs.getString('number') ?? '';
      _addressController.text = prefs.getString('address') ?? '';
      _companyController.text = prefs.getString('company') ?? '';
      _childrenCount = prefs.getInt('childrenCount') ?? 0;
      _childrenCountController.text = _childrenCount.toString();

      // Cargar datos de los hijos
      _childrenData = List.generate(_childrenCount, (index) {
        String childName =
            prefs.getString('childName$index') ?? 'Hijo ${index + 1}';
        bool childIsStudent = prefs.getBool('childIsStudent$index') ?? false;
        ChildData childData =
            ChildData(name: childName, isStudent: childIsStudent);
        childData.birthdateController.text =
            prefs.getString('childBirthdate$index') ?? '';
        return childData;
      });

      // Cargar la imagen de perfil si existe
      String? imagePath = prefs.getString('profileImagePath');
      if (imagePath != null) {
        _image = File(imagePath);
      }
    });
  }

  void _editChildName(int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        String newName = _childrenData[index].nameController.text;
        return AlertDialog(
          title: const Text('Editar nombre'),
          content: TextField(
            onChanged: (value) {
              newName = value;
            },
            controller: TextEditingController(text: newName),
            decoration:
                const InputDecoration(hintText: "Ingrese el nuevo nombre"),
          ),
          actions: <Widget>[
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor:
                    Colors.blue, // Cambia el color del texto a azul
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancelar'),
            ),
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor:
                    Colors.blue, // Cambia el color del texto a azul
              ),
              onPressed: () {
                setState(() {
                  _childrenData[index].nameController.text = newName;
                });
                Navigator.of(context).pop();
              },
              child: const Text('Guardar'),
            ),
          ],
        );
      },
    );
  }
}
