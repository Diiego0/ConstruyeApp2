// lib/services/event_tracker.dart
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'dart:async';
import 'dart:collection';
import 'package:shared_preferences/shared_preferences.dart';

class EventTracker {
  static final EventTracker _instance = EventTracker._internal();
  factory EventTracker() => _instance;
  
  final _dio = Dio();
  final _queue = Queue<Map<String, dynamic>>();
  final _batchSize = 10;
  Timer? _flushTimer;
  bool _isFlushing = false;
  String? _currentUserId;

  EventTracker._internal() {
    _dio.options.baseUrl = 'https://construbotadmin.azurewebsites.net';
    _startFlushTimer();
    _initializeUser();
  }

  Future<void> _initializeUser() async {
    final prefs = await SharedPreferences.getInstance();
    _currentUserId = prefs.getString('rut');
  }

  void _startFlushTimer() {
    _flushTimer?.cancel();
    _flushTimer = Timer.periodic(Duration(seconds: 30), (timer) {
      if (_queue.isNotEmpty && !_isFlushing) {
        _flush();
      }
    });
  }

  Future<void> capture({
    required String eventName,
    Map<String, dynamic>? properties,
  }) async {
    if (_currentUserId == null) {
      await _initializeUser();
    }

    try {
      // Asegurar que properties sea serializable
      final sanitizedProperties = properties?.map(
        (key, value) => MapEntry(
          key,
          value is DateTime ? value.toIso8601String() : value,
        ),
      ) ?? {};

      final event = {
        'name': eventName,
        'timestamp': DateTime.now().toIso8601String(),
        'properties': sanitizedProperties,
        'user_id': _currentUserId,
      };

      // Verificar que el evento sea serializable
      jsonEncode(event); // Esto lanzará un error si no es serializable

      _queue.add(event);

      if (_queue.length >= _batchSize && !_isFlushing) {
        await _flush();
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error creating event: $e');
        print('Event name: $eventName');
        print('Properties: $properties');
      }
    }
  }

  Future<void> identify(String userId, {Map<String, dynamic>? userProperties}) async {
    _currentUserId = userId;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('rut', userId);
  }

  Future<void> logError({
    required String errorType,
    required String message,
    String? stackTrace,
    Map<String, dynamic>? properties,
  }) async {
    try {
      await _dio.post('/api/track-error/', data: {
        'error_type': errorType,
        'error_message': message,
        'stack_trace': stackTrace,
        'user_id': _currentUserId,
        'properties': properties ?? {},
      });
    } catch (e) {
      if (kDebugMode) {
        print('Error sending error event: $e');
      }
    }
  }

Future<void> _flush() async {
  if (_queue.isEmpty || _isFlushing) return;
  _isFlushing = true;
  final events = List<Map<String, dynamic>>.from(_queue);
  _queue.clear();

  try {
    // Convertir explícitamente a JSON para asegurar que todo es serializable
    final jsonEvents = events.map((event) {
      try {
        return {
          'name': event['name'],
          'timestamp': event['timestamp'],
          'properties': Map<String, dynamic>.from(event['properties'] ?? {}),
          'user_id': event['user_id'],
        };
      } catch (e) {
        if (kDebugMode) {
          print('Error convirtiendo evento: $e');
          print('Evento problemático: $event');
        }
        return null;
      }
    }).where((event) => event != null).toList();

    if (kDebugMode) {
      print('Enviando eventos: ${jsonEncode(jsonEvents)}');
    }

    await _dio.post(
      '/api/track-batch/',
      data: {'events': jsonEvents},
      options: Options(
        headers: {
          'Content-Type': 'application/json',
        },
        validateStatus: (status) => status! < 500,
      ),
    );
  } catch (e, stackTrace) {
    if (kDebugMode) {
      print('Error flushing events: $e');
      print('Stack trace: $stackTrace');
      if (e is DioException) {
        print('Response data: ${e.response?.data}');
        print('Response headers: ${e.response?.headers}');
        print('Request data: ${e.requestOptions.data}');
      }
    }
    events.forEach(_queue.add);
  } finally {
    _isFlushing = false;
  }
}


  void dispose() {
    _flushTimer?.cancel();
    _flush();
  }
}

final tracker = EventTracker();