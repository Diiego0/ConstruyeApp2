import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class QuickQuestion {
  final int id;
  final String question;
  final String type;

  QuickQuestion({
    required this.id,
    required this.question,
    required this.type,
  });

  factory QuickQuestion.fromJson(Map<String, dynamic> json) {
    return QuickQuestion(
      id: json['id'],
      question: json['question'],
      type: json['type'],
    );
  }
}

class QuickQuestionsService {
  static const String baseUrl = 'https://construbotadmin.azurewebsites.net';
  
  // Mantenemos las preguntas por defecto
  static final List<QuickQuestion> defaultQuestions = [
    QuickQuestion(id: 1, question: 'Consejo de seguridad', type: 'general'),
    QuickQuestion(id: 2, question: 'Ver nuevos eventos', type: 'general'),
    QuickQuestion(id: 3, question: 'Asistencia técnica', type: 'general'),
    QuickQuestion(id: 4, question: 'Mis certificados', type: 'general'),
  ];

  Future<List<QuickQuestion>> getQuestions() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final hasChildren = prefs.getBool('has_children') ?? false;
      
      // Log para ver la URL completa
      final url = '$baseUrl/api/quick-questions/?has_children=${hasChildren ? 'yes' : 'no'}';
      if (kDebugMode) {
        print('Intentando conectar a: $url');
        print('Usuario tiene hijos: $hasChildren');
      }
     
      final response = await http.get(Uri.parse(url));

      if (kDebugMode) {
        print('Status code: ${response.statusCode}');
        print('Respuesta: ${response.body}');
      }

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        final questions = (data['questions'] as List)
            .map((question) => QuickQuestion.fromJson(question))
            .toList();
            
        if (kDebugMode) {
          print('Preguntas recibidas de la API: ${questions.length}');
          for (var q in questions) {
            print('ID: ${q.id}, Pregunta: ${q.question}');
          }
        }

        return questions.isEmpty ? defaultQuestions : questions;
      } else {
        if (kDebugMode) {
          print('Error en la API: ${response.statusCode}');
          print('Usando preguntas por defecto');
        }
        return defaultQuestions;
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error al hacer la petición: $e');
        print('Usando preguntas por defecto');
      }
      return defaultQuestions;
    }
  }
}