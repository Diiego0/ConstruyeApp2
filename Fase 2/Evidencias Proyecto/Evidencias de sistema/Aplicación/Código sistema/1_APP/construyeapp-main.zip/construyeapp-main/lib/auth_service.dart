// lib/auth_service.dart
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'urls.dart';
import 'dart:convert';

class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  final _storage = const FlutterSecureStorage();

  Future<void> saveToken(String token) async {
    await _storage.write(key: 'auth_token', value: token);
  }

  Future<void> saveUserId(String userId) async {
    await _storage.write(key: 'user_id', value: userId);
  }

  Future<String?> getToken() async {
    return await _storage.read(key: 'auth_token');
  }

  Future<String?> getUserId() async {
    return await _storage.read(key: 'user_id');
  }

  Future<void> clearCredentials() async {
    await _storage.delete(key: 'auth_token');
    await _storage.delete(key: 'user_id');
  }

  // Método para verificar si el token es válido
  Future<bool> isTokenValid() async {
    final token = await getToken();
    if (token == null) return false;

    // Aquí podrías añadir lógica adicional para verificar la validez del token
    // Por ejemplo, decodificar el JWT y verificar la fecha de expiración

    return true;
  }

  //Perfil usuario
  Future<void> saveUserPerfil(
    String name,
    String lastName,
    String rut,
    String number,
    String email,
    String address,
    String company,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('name', name);
    await prefs.setString('lastName', lastName);
    await prefs.setString('rut', rut);
    await prefs.setString('number', number);
    await prefs.setString('email', email);
    await prefs.setString('address', address);
    await prefs.setString('company', company);
  }

  // Función para cargar datos del procedimiento almacenado
  Future<void> loadUserPerfilFromDB(String rut) async {
    String errorMessage = '';
    //bool isLoading = false;
    final String url = urlPerfil;

    try {
      print('Cargando perfil para: $rut'); // Debug

      //isLoading = true;
      errorMessage = '';

      final response = await http.post(
        Uri.parse(url),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{
          'rut': rut,
        }),
      );

      print('Status Code: ${response.statusCode}'); // Debug
      print('Response body: ${response.body}'); // Debug

      if (response.body.isEmpty) {
        errorMessage = 'El servidor no envió respuesta';
        return;
      }

      try {
        final responseData = json.decode(response.body);

        if (response.statusCode == 200) {
          // Separar NombreCompleto
          List<String> nombreCompleto =
              responseData['NombreCompleto'].toString().split(' ');
          String apellido = nombreCompleto.length > 1
              ? '${nombreCompleto[0]} ${nombreCompleto[1]}'
              : nombreCompleto[0]; // Toma los dos primeros como apellidos
          String nombre = nombreCompleto.length > 2
              ? nombreCompleto.sublist(2).join(' ')
              : ''; // Toma el resto como nombres

          // Guardar datos en SharedPreferences
          await saveUserPerfil(
            nombre,
            apellido,
            '${responseData['RUTUsuario']}-${responseData['DV']}',
            responseData['NumeroTelefono'] ?? '',
            responseData['Email'] ?? '',
            responseData['Direccion'] ?? 'No Registra',
            '', // Company
          );

          print('Perfil cargado exitosamente'); // Debug
        } else {
          errorMessage = responseData['error'] ?? 'Error al cargar el perfil';
          print('Error al cargar perfil: $errorMessage'); // Debug
        }
      } on FormatException catch (e) {
        errorMessage =
            'Error al procesar la respuesta del servidor: ${e.toString()}';
      }
    } catch (e) {
      errorMessage = 'Error de conexión: ${e.toString()}';
      print('Error de conexión: $e'); // Debug
    } finally {
      //isLoading = false;
    }
    // Si hay un error, podrías manejarlo como prefieras
    if (errorMessage.isNotEmpty) {
      print('Error final: $errorMessage');
    }
  }
}
