# construyeapp

Aplicación móvil hecha en flutter para el cliente Bravo Izquierdo/CChC

Consiste en un Chatbot de copilot studio capaz de ayudar al personal, a agilizar el trabajo al inscribir beneficios y a los trabajadores de la construcción al informarse de los mismos.

- Contiene una interfaz de chat para interactuar con el chatbot
- 
