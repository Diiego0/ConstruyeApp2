// lib/inicio_chatbot_logic.dart
// ignore_for_file: constant_identifier_names

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:construyeapp/widgets/event_tracker.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'widgets/chat_message_bubble.dart';
import 'main.dart';

class InicioChatBotLogic {
  String directLineToken = '';
  String conversationId = '';
  String? lastProcessedMessageId;
  List<ChatMessage> messages = [];
  Timer? _pollingTimer;
  String? watermark;
  String userId = 'user_${DateTime.now().millisecondsSinceEpoch}';
  String userMessageId = '';
  final bool _isChatClosed = false;
  late final DateTime _sessionStartTime;
  final Function(List<ChatMessage>) onMessagesUpdated;
  final Function(bool) onWaitingForResponseChanged;
  final Function() onChatClosed;
    int _connectionRetryCount = 0;
  static const int MAX_RETRY_ATTEMPTS = 3;
  bool _isReconnecting = false;
  DateTime? _lastConnectionAttempt;
  static const Duration RETRY_COOLDOWN = Duration(minutes: 1);
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  InicioChatBotLogic({
    required this.onMessagesUpdated,
    required this.onWaitingForResponseChanged,
    required this.onChatClosed,
  }){_getChatList();}

Future<void> initialize() async {
  try {
    bool hasExistingSession = await loadTokenAndConversationId();
    _sessionStartTime = DateTime.now();
    tracker.capture(
      eventName: 'Chat_Session_Started',
      properties: {
        'session_type': hasExistingSession ? 'resumed' : 'new',
        'conversation_id': conversationId,
        'session_start_time': _sessionStartTime.toIso8601String(), // Agregar esto también
      },
    );
    
    if (hasExistingSession) {
      messages.clear();
      watermark = null;
      if (kDebugMode) {
        print("Resuming existing conversation");
      }
      _startPolling();
    } else {
      await _getDirectLineToken();
    }
  } catch (e) {
    if (kDebugMode) {
      print('Error in initialize: $e');
    }
    
    tracker.capture(
      eventName: 'Chat_Initialize_Error',
      properties: {'error': e.toString()},
    );
  }
}

  Future<void> saveTokenAndConversationId() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('direct_line_token', directLineToken);
    await prefs.setString('conversation_id', conversationId);
  }

  Future<bool> loadTokenAndConversationId() async {
    final prefs = await SharedPreferences.getInstance();
    directLineToken = prefs.getString('direct_line_token') ?? '';
    conversationId = prefs.getString('conversation_id') ?? '';
    return directLineToken.isNotEmpty && conversationId.isNotEmpty;
  }

Future<void> clearTokenAndConversationId() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.remove('direct_line_token');
  await prefs.remove('conversation_id');

  // Mensajes de depuración para verificar que las credenciales fueron eliminadas
  String? token = prefs.getString('direct_line_token');
  String? conversationId = prefs.getString('conversation_id');
  if (token == null && conversationId == null) {
    if (kDebugMode) {
      print('Credenciales eliminadas correctamente.');
    }
  } else {
    if (kDebugMode) {
      print('Error al eliminar credenciales. direct_line_token: $token, conversation_id: $conversationId');
    }
  }
}

Future<String?> getRutFromPrefs() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('rut'); // El 'rut' ya debe haber sido guardado en SharedPreferences
}


Future<void> _updateLastMessageTime(String conversationId) async {
  const String azureFunctionUrl = 'https://hconstrubot.azurewebsites.net/api/cerrarchat';
  String? rut = await getRutFromPrefs();  // Obtener el RUT dinámicamente
  
  if (rut == null) {
    if (kDebugMode) {
      print('Error: No se pudo obtener el RUT.');
    }
    return;
  }
  
  String? deviceToken = await FirebaseMessaging.instance.getToken();
  
  // Debug para mostrar el deviceToken
  if (kDebugMode) {
    print('Device Token: $deviceToken');
  }
  
  if (deviceToken == null) {
    if (kDebugMode) {
      print('Error: No se pudo obtener el token del dispositivo.');
    }
    return;
  }
  
  try {
    final response = await http.post(
      Uri.parse(azureFunctionUrl),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'token': directLineToken,
        'conversationId': conversationId,
        'deviceToken': deviceToken,
        'rut': rut,  // Usar el RUT obtenido
      }),
    );

    if (response.statusCode == 200) {
      if (kDebugMode) {
        print('Timer reset for conversation: $conversationId');
      }
      // Tracking de éxito
      tracker.capture(
        eventName: 'Message_Timer_Update',
        properties: {
          'conversation_id': conversationId,
          'success': true,
          'has_device_token': true,
        },
      );
    } else {
      if (kDebugMode) {
        print('Failed to reset timer: ${response.statusCode}');
      }
      // Tracking de error HTTP
      tracker.capture(
        eventName: 'Message_Timer_Update',
        properties: {
          'conversation_id': conversationId,
          'success': false,
          'status_code': response.statusCode,
          'has_device_token': true,
        },
      );
    }
  } catch (e) {
    if (kDebugMode) {
      print('Error resetting timer: $e');
    }
    // Tracking de excepción
    tracker.capture(
      eventName: 'Message_Timer_Error',
      properties: {
        'error': e.toString(),
        'conversation_id': conversationId,
      },
    );
  }
}



Future<bool> isChatClosed() async {
  final prefs = await SharedPreferences.getInstance();
  directLineToken = prefs.getString('direct_line_token') ?? '';
  conversationId = prefs.getString('conversation_id') ?? '';

  // Check if either the conversationId or directLineToken is missing
  if (conversationId.isEmpty || directLineToken.isEmpty) {
    return true;  // Chat is closed
  }

  return _isChatClosed;
}

  
Future<void> continuarConversacion(String chatId) async {
  if (kDebugMode) {
    print("Iniciando continuación de conversación para chatId: $chatId");
  }
  
  tracker.capture(
    eventName: 'Continue_Conversation_Started',
    properties: {'chat_id': chatId},
  );
  
  try {
    await loadChatFromHistory(chatId);
    await _getDirectLineToken();
    
    if (messages.isNotEmpty) {
      ChatMessage lastMessage = messages.last;
      
      if (kDebugMode) {
        print("Último mensaje obtenido: ${lastMessage.text}");
      }
      
      String prompt = "Continuemos nuestra conversación. Aquí un resumen: '${lastMessage.text}'";
      
      await sendMessage(prompt);
      
      tracker.capture(
        eventName: 'Continue_Conversation_Success',
        properties: {
          'chat_id': chatId,
          'message_count': messages.length,
          'has_last_message': true,
        },
      );
    } else {
      if (kDebugMode) {
        print("No se encontraron mensajes para el chat ID: $chatId");
      }
      
      tracker.capture(
        eventName: 'Continue_Conversation_Empty',
        properties: {
          'chat_id': chatId,
          'reason': 'no_messages',
        },
      );
    }
  } catch (e) {
    if (kDebugMode) {
      print("Error continuando conversación: $e");
    }
    
    tracker.capture(
      eventName: 'Continue_Conversation_Error',
      properties: {
        'chat_id': chatId,
        'error': e.toString(),
      },
    );
  }
}


Future<void> saveChatToAzure(String conversationId, List<ChatMessage> messages) async {
  String? rut = await getRutFromPrefs();

  if (rut == null) {
    tracker.capture(
      eventName: 'Save_Chat_Error',
      properties: {'error': 'Missing_RUT'}
    );
    if (kDebugMode) {
      print('Error: No se pudo obtener el RUT.');
    }
    return;
  }

  final url = Uri.parse('https://hconstrubot.azurewebsites.net/api/savehistory');

  try {
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'conversationId': conversationId,
        'messages': messages.map((msg) => msg.toJson()).toList(),
        'rut': rut,
      }),
    );

    if (response.statusCode == 200) {
      if (kDebugMode) {
        print('Chat history saved successfully');
      }
      
      tracker.capture(
        eventName: 'Chat_Saved',
        properties: {
          'success': true,
          'message_count': messages.length,
          'conversation_id': conversationId,
        },
      );
    } else {
      if (kDebugMode) {
        print('Failed to save chat history: ${response.statusCode}');
      }
      
      tracker.capture(
        eventName: 'Chat_Save_Failed',
        properties: {
          'status_code': response.statusCode,
          'conversation_id': conversationId,
        },
      );
    }
  } catch (e) {
    if (kDebugMode) {
      print('Error occurred while saving chat: $e');
    }
    
    tracker.capture(
      eventName: 'Chat_Save_Exception',
      properties: {
        'error': e.toString(),
        'conversation_id': conversationId,
      },
    );
  }
}


Future<void> loadChatFromHistory(String chatId) async {
  String? rut = await getRutFromPrefs();  // Obtener el RUT dinámicamente

  if (rut == null) {
    if (kDebugMode) {
      print('Error: No se pudo obtener el RUT.');
    }
    
    tracker.capture(
      eventName: 'Load_Chat_Error',
      properties: {'error': 'Missing_RUT'}
    );
    return;
  }

  final url = Uri.parse('https://hconstrubot.azurewebsites.net/api/loadchatfromhistory?chatId=$chatId&rut=$rut');

  try {
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final chatData = jsonDecode(response.body);
      conversationId = chatId;
      messages = (chatData['messages'] as List)
          .map((msg) => ChatMessage.fromJson(msg))
          .toList();
      onMessagesUpdated(messages);

      if (kDebugMode) {
        print("Chat cargado desde Azure. Número de mensajes: ${messages.length}");
      }

      tracker.capture(
        eventName: 'Chat_History_Loaded',
        properties: {
          'chat_id': chatId,
          'message_count': messages.length,
          'successful': true,
        },
      );
    } else {
      if (kDebugMode) {
        print("No se encontró el chat con ID: $chatId o error en el servidor");
      }

      tracker.capture(
        eventName: 'Chat_History_Load_Failed',
        properties: {
          'chat_id': chatId,
          'status_code': response.statusCode,
        },
      );
    }
  } catch (e) {
    if (kDebugMode) {
      print("Error cargando el chat desde Azure: $e");
    }

    tracker.capture(
      eventName: 'Chat_History_Load_Exception',
      properties: {
        'chat_id': chatId,
        'error': e.toString(),
      },
    );
  }
}


Future<void> _getChatList() async {
  String? rut = await getRutFromPrefs();
  final url = Uri.parse('https://hconstrubot.azurewebsites.net/api/getchatlist?rut=$rut');

  try {
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final chatList = jsonDecode(response.body);
      
      if (chatList is Map<String, dynamic>) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('chat_history', json.encode(chatList));
        if (kDebugMode) {
          print("Lista de chats guardada en SharedPreferences: $chatList");
        }
        
        tracker.capture(
          eventName: 'Chat_List_Retrieved',
          properties: {
            'success': true,
            'chat_count': chatList.length,
            'has_rut': rut != null,
          },
        );
      } else {
        if (kDebugMode) {
          print("Error: La respuesta de la API no es un Map<String, dynamic>");
        }
        
        tracker.capture(
          eventName: 'Chat_List_Error',
          properties: {
            'error': 'Invalid_Response_Format',
            'has_rut': rut != null,
          },
        );
      }
    } else {
      if (kDebugMode) {
        print("Error obteniendo la lista de chats: ${response.statusCode}");
      }
      
      tracker.capture(
        eventName: 'Chat_List_Failed',
        properties: {
          'status_code': response.statusCode,
          'has_rut': rut != null,
        },
      );
    }
  } catch (e) {
    if (kDebugMode) {
      print("Error obteniendo la lista de chats desde Azure: $e");
    }
    
    tracker.capture(
      eventName: 'Chat_List_Exception',
      properties: {
        'error': e.toString(),
        'has_rut': rut != null,
      },
    );
  }
}


Future<void> reiniciarChat() async {
  try {
    final oldConversationId = conversationId;
    final messageCount = messages.length;
    final sessionDuration = DateTime.now().difference(_sessionStartTime).inMilliseconds;
    await saveChatToAzure(conversationId, messages.cast<ChatMessage>());
    
    tracker.capture(
      eventName: 'Chat_Reset',
      properties: {
        'old_conversation_id': oldConversationId,
        'message_count': messageCount,
        'session_duration_ms': sessionDuration,
        'reason': 'user_initiated',
      },
    );

    // Limpiar el estado actual del chat
    messages.clear();
    conversationId = '';
    lastProcessedMessageId = null;
    watermark = null;
    directLineToken = '';

    if (kDebugMode) {
      print('Estado del chat reiniciado.');
    }

    await clearTokenAndConversationId();
    userId = 'user_${DateTime.now().millisecondsSinceEpoch}';
    _pollingTimer?.cancel();
    await initialize();

    if (kDebugMode) {
      print('Chat reiniciado. Nuevo userId: $userId');
    }

    onMessagesUpdated(messages);
    onChatClosed();
    
    tracker.capture(
      eventName: 'Chat_Reset_Completed',
      properties: {
        'new_user_id': userId,
        'success': true,
      },
    );

  } catch (error) {
    if (kDebugMode) {
      print('Error saving chat: $error');
    }
    
    tracker.capture(
      eventName: 'Chat_Reset_Error',
      properties: {
        'error': error.toString(),
        'phase': 'reset_process',
      },
    );
  }
}


  Future<bool> _validateToken() async {
    if (directLineToken.isEmpty) return false;

    try {
      const url = 'https://construbot.azurewebsites.net/api/getactivities';
      final response = await http.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'token': directLineToken,
          'conversationId': conversationId,
          'watermark': watermark,
        }),
      );

      return response.statusCode != 403;
    } catch (e) {
      if (kDebugMode) {
        print('Error validating token: $e');
      }
      return false;
    }
  }

  Future<bool> _handleConnectionFailure() async {
    if (_isReconnecting) return false;
    _isReconnecting = true;

    try {
      if (_lastConnectionAttempt != null) {
        final timeSinceLastAttempt = DateTime.now().difference(_lastConnectionAttempt!);
        if (timeSinceLastAttempt < RETRY_COOLDOWN) {
          if (kDebugMode) {
            print('Waiting for cooldown period before retry...');
          }
          _isReconnecting = false;
          return false;
        }
      }

      _connectionRetryCount++;
      if (_connectionRetryCount > MAX_RETRY_ATTEMPTS) {
        if (kDebugMode) {
          print('Max retry attempts exceeded');
        }
        _isReconnecting = false;
        return false;
      }

      // Limpiar credenciales existentes
      await clearTokenAndConversationId();
      
      // Intentar obtener nuevo token
      await _getDirectLineToken();
      
      // Validar nueva conexión
      final isValid = await _validateToken();
      if (isValid) {
        _connectionRetryCount = 0;
        _lastConnectionAttempt = DateTime.now();
        _isReconnecting = false;
        return true;
      }

      _isReconnecting = false;
      return false;
    } catch (e) {
      if (kDebugMode) {
        print('Error in connection retry: $e');
      }
      _isReconnecting = false;
      return false;
    }
  }



  //conexión al token de copilot
  // _getDirectLineToken y _startConversation se podrían unir más adelante
  Future<void> _getDirectLineToken() async {
    try {
      const String azureFunctionUrl = 'https://construbot.azurewebsites.net/api/triggerconecchatbot';
      
      final response = await http.get(Uri.parse(azureFunctionUrl));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        directLineToken = data['token'];
        await saveTokenAndConversationId();
        
        tracker.capture(
          eventName: 'DirectLine_Token_Retrieved',
          properties: {
            'success': true,
            'retry_count': _connectionRetryCount,
          },
        );
        
        await _startConversation();
      } else {
        if (kDebugMode) {
          print('Failed to get Direct Line token: ${response.statusCode}');
        }
        
        if (response.statusCode == 403) {
          await _handleConnectionFailure();
        }
        
        tracker.capture(
          eventName: 'DirectLine_Token_Failed',
          properties: {
            'status_code': response.statusCode,
            'retry_count': _connectionRetryCount,
          },
        );
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error getting Direct Line token: $e');
      }
      
      await _handleConnectionFailure();
      
      tracker.capture(
        eventName: 'DirectLine_Token_Error',
        properties: {
          'error': e.toString(),
          'retry_count': _connectionRetryCount,
        },
      );
    }
  }

  //se comprueba que se haya establecido conexión
Future<void> _startConversation() async {
  try {
    const String azureFunctionUrl = 'https://construbot.azurewebsites.net/api/startconversation';
    
    final response = await http.post(
      Uri.parse(azureFunctionUrl),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({'token': directLineToken})
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      conversationId = data['conversationId'];
      await saveTokenAndConversationId();
      if (kDebugMode) {
        print('Nueva conversación iniciada. ID: $conversationId');
      }
      
      tracker.capture(
        eventName: 'Conversation_Started',
        properties: {
          'conversation_id': conversationId,
          'success': true,
        },
      );
      
      _startPolling();
    } else {
      if (kDebugMode) {
        print('Failed to start conversation: ${response.statusCode}');
      }
      
      tracker.capture(
        eventName: 'Conversation_Start_Failed',
        properties: {
          'status_code': response.statusCode,
        },
      );
    }
  } catch (e) {
    if (kDebugMode) {
      print('Error starting conversation: $e');
    }
    
    tracker.capture(
      eventName: 'Conversation_Start_Error',
      properties: {'error': e.toString()},
    );
  }
}

  //tiempo de demora entre mensajes, para evitar duplicados
  void _startPolling() {
    _pollingTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _getActivities();
    });
  }

  //getActivities y sendMessage encargados de procesar los mensajes de bot/usuario
  //el getActivities y sendMessage más adelante se podrían juntar en uno solo
Future<void> _getActivities() async {
  if (conversationId.isEmpty) {
    tracker.capture(
      eventName: 'Activities_Error',
      properties: {'error': 'Empty_Conversation_ID'}
    );
    if (kDebugMode) {
      print("ConversationId está vacío, no se pueden obtener actividades");
    }
    return;
  }

  tracker.capture(
    eventName: 'Activities_Request_Started',
    properties: {
      'conversation_id': conversationId,
      'watermark': watermark,
    },
  );

  const url = 'https://construbot.azurewebsites.net/api/getactivities';
  final headers = {
    'Content-Type': 'application/json',
  };

  final body = json.encode({
    'token': directLineToken,
    'conversationId': conversationId,
    'watermark': watermark,
  });

  try {
    final response = await http.post(Uri.parse(url), headers: headers, body: body);
    
    // Manejo de token inválido
    if (response.statusCode == 403) {
      if (kDebugMode) {
        print('Token inválido detectado en getActivities, intentando reconexión...');
      }
      
      tracker.capture(
        eventName: 'Activities_Token_Invalid',
        properties: {
          'conversation_id': conversationId,
          'retry_count': _connectionRetryCount,
        },
      );

      // Intentar reconexión
      final reconnected = await _handleConnectionFailure();
      if (!reconnected) {
        if (kDebugMode) {
          print('No se pudo reconectar después de token inválido');
        }
        
        tracker.capture(
          eventName: 'Activities_Reconnection_Failed',
          properties: {
            'conversation_id': conversationId,
            'retry_count': _connectionRetryCount,
          },
        );
        return;
      }
      
      // Si la reconexión fue exitosa, reintentar getActivities
      if (_pollingTimer != null) {
        return; // El siguiente ciclo de polling manejará la obtención de actividades
      }
    }

    if (response.statusCode == 200) {
      tracker.capture(
        eventName: 'Activities_Response_Success',
        properties: {
          'conversation_id': conversationId,
          'status_code': response.statusCode,
        },
      );

      final responseBody = utf8.decode(response.bodyBytes);
      final data = json.decode(responseBody);
      final activities = data['activities'] as List;
      final newWatermark = data['watermark'];

      bool messagesUpdated = false;
      for (var activity in activities) {
        if (activity['type'] == 'message') {
          final activityId = activity['id'] ?? '';
          
          if (watermark == null || activityId.compareTo(watermark!) > 0) {
            final from = activity['from'] ?? {};
            var text = activity['text'] ?? '';
            final fromId = from['id'] ?? 'Unknown';
            final fromName = from['name'] ?? 'Usuario';

            // Procesar citations y textSummary si existen
            List<Citation>? citations;
            if (activity['entities'] != null) {
              final entities = activity['entities'] as List;
              for (var entity in entities) {
                if (entity['type'] == 'https://schema.org/Message' && 
                    entity['citation'] != null) {
                  // Intentar obtener textSummary
                  if (activity['channelData'] != null &&
                      activity['channelData']['pva:gpt-feedback'] != null &&
                      activity['channelData']['pva:gpt-feedback']['summarizationOpenAIResponse'] != null &&
                      activity['channelData']['pva:gpt-feedback']['summarizationOpenAIResponse']['result'] != null &&
                      activity['channelData']['pva:gpt-feedback']['summarizationOpenAIResponse']['result']['textSummary'] != null) {
                    
                    final summaryText = activity['channelData']['pva:gpt-feedback']['summarizationOpenAIResponse']['result']['textSummary'];
                    if (summaryText.toString().isNotEmpty) {
                      text = summaryText;
                    }
                  }

                  citations = (entity['citation'] as List).map((citation) {
                    final appearance = citation['appearance'] as Map<String, dynamic>;
                    final id = citation['@id'] ?? '';
                    final url = id.startsWith('http') ? id : null;
                    
                    return Citation(
                      position: citation['position'],
                      text: appearance['text'] ?? '',
                      url: url,
                      title: appearance['abstract'] ?? appearance['name'] ?? '',
                    );
                  }).toList();

                  if (kDebugMode) {
                    print('Citations procesadas: ${citations.length}');
                    for (var citation in citations) {
                      print('Citation ${citation.position}: ${citation.text}');
                      print('URL: ${citation.url}');
                      print('Title: ${citation.title}');
                    }
                  }
                }
              }
            }

            if (idUsuario == '') {
              idUsuario = fromId;
            }
            final isUser = fromId == idUsuario;
            final senderName = isUser
                ? 'Usuario'
                : (fromName != 'Unknown' ? fromName : 'Bot el constructor');

            int existingIndex = messages.indexWhere((msg) => 
              msg.id == activityId || (msg.id.startsWith('temp_') && msg.text == text && msg.isUser == isUser)
            );

            if (existingIndex != -1) {
              if (messages[existingIndex].id.startsWith('temp_')) {
                messages[existingIndex] = ChatMessage(
                  id: activityId,
                  text: text,
                  isUser: isUser,
                  senderName: senderName,
                  citations: citations,
                );
                messagesUpdated = true;
              }
            } else {
              messages.add(ChatMessage(
                id: activityId,
                text: text,
                isUser: isUser,
                senderName: senderName,
                citations: citations,
              ));
              messagesUpdated = true;
            }

            if (messagesUpdated && !isUser) {
              tracker.capture(
                eventName: 'Bot_Response_Received',
                properties: {
                  'response_length': text.length,
                  'has_citations': citations?.isNotEmpty ?? false,
                  'citations_count': citations?.length ?? 0,
                  'conversation_id': conversationId,
                  'message_count': messages.length,
                },
              );
            }

            if (kDebugMode) {
              print("Mensaje procesado: $text");
              if (citations != null) {
                print("Citations encontradas: ${citations.length}");
              }
              print("Total de mensajes ahora: ${messages.length}");
            }
          }
        }
      }

      if (newWatermark != null && newWatermark != watermark) {
        watermark = newWatermark;
      }

      if (messagesUpdated) {
        onMessagesUpdated(messages);
        onWaitingForResponseChanged(false);
        await saveChatToAzure(conversationId, messages.cast<ChatMessage>());
      }

      // Resetear el contador de reintentos si todo fue exitoso
      _connectionRetryCount = 0;
    }
  } catch (e) {
    if (kDebugMode) {
      print('Error getting activities: $e');
    }
    
    tracker.capture(
      eventName: 'Activities_Error',
      properties: {
        'error': e.toString(),
        'conversation_id': conversationId,
      },
    );

    // Intentar reconexión si el error podría estar relacionado con la conexión
    if (e is IOException || e.toString().contains('HttpException')) {
      await _handleConnectionFailure();
    }
  }
}

Future<void> _setChatbotInteraction() async {
  final prefs = await SharedPreferences.getInstance();
  prefs.setBool('has_interacted_with_chatbot', true);  // Guardar estado
  if (kDebugMode) {
    print("DEBUG: El usuario ya ha interactuado con el chatbot, solicitando reseña.");
  }
}

Future<void> sendMessage(String text) async {
  if (kDebugMode) {
    print("Iniciando envío de mensaje: $text");
  }
  if (text.trim().isEmpty) return;

  tracker.capture(
    eventName: 'Message_Sent',
    properties: {
      'message_length': text.length,
      'is_first_message': messages.isEmpty,
      'conversation_id': conversationId,
      'message_type': 'user_message',
      'response_time_start': DateTime.now().toIso8601String(),
      'message_count': messages.length,
    },
  );

  await _setChatbotInteraction();
  onWaitingForResponseChanged(true);
  final tempMessageId = 'temp_${DateTime.now().millisecondsSinceEpoch}';
  
  // Añadir el mensaje localmente con un ID temporal
  messages.add(ChatMessage(
    id: tempMessageId,
    text: text,
    isUser: true,
    senderName: 'Usuario',
  ));
  onMessagesUpdated(messages);

  try {
    const url = 'https://construbot.azurewebsites.net/api/sendmessage';
    final headers = {'Content-Type': 'application/json'};
    final body = json.encode({
      'token': directLineToken,
      'conversationId': conversationId,
      'message': text,
    });

    if (kDebugMode) {
      print("Enviando solicitud HTTP para enviar mensaje");
      print("URL: $url");
      print("Headers: $headers");
      print("Body: $body");
    }

    final response = await http.post(
      Uri.parse(url),
      headers: headers,
      body: body,
    );

    if (kDebugMode) {
      print("Código de estado de respuesta: ${response.statusCode}");
      print("Cuerpo de respuesta: ${response.body}");
    }

    if (response.statusCode == 403) {
      if (kDebugMode) {
        print('Token invalid, attempting reconnection...');
      }

      tracker.capture(
        eventName: 'Message_Send_Token_Invalid',
        properties: {
          'conversation_id': conversationId,
          'retry_count': _connectionRetryCount,
        },
      );
      
      final reconnected = await _handleConnectionFailure();
      if (reconnected) {
        // Reintentar envío del mensaje
        await sendMessage(text);
        return;
      } else {
        throw Exception('Failed to reconnect after token expiration');
      }
    }

    if (response.statusCode == 200) {
      if (kDebugMode) {
        print("Mensaje enviado exitosamente");
      }

      final responseData = json.decode(response.body);
      final serverMessageId = responseData['id'] ?? tempMessageId;
      
      // Actualizar el ID del mensaje temporal con el ID del servidor
      final index = messages.indexWhere((msg) => msg.id == tempMessageId);
      if (index != -1) {
        messages[index] = ChatMessage(
          id: serverMessageId,
          text: text,
          isUser: true,
          senderName: 'Usuario',
        );
        onMessagesUpdated(messages);
      }

      await saveChatToAzure(conversationId, messages.cast<ChatMessage>());
      await _updateLastMessageTime(conversationId);

      tracker.capture(
        eventName: 'Message_Send_Success',
        properties: {
          'conversation_id': conversationId,
          'message_id': serverMessageId,
        },
      );

    } else {
      if (kDebugMode) {
        print('Failed to send message: ${response.statusCode}');
        print('Response body: ${response.body}');
      }

      tracker.capture(
        eventName: 'Message_Send_Failed',
        properties: {
          'conversation_id': conversationId,
          'status_code': response.statusCode,
          'error': response.body,
        },
      );

      onWaitingForResponseChanged(false);
    }
  } catch (e) {
    if (kDebugMode) {
      print('Error sending message: $e');
    }

    tracker.capture(
      eventName: 'Message_Send_Error',
      properties: {
        'conversation_id': conversationId,
        'error': e.toString(),
      },
    );

    onWaitingForResponseChanged(false);
  } finally {
    onWaitingForResponseChanged(false);
  }
}

  void dispose() {
    tracker.capture(
    eventName: 'Chat_Session_Ended',
    properties: {
      'conversation_id': conversationId,
      'total_messages': messages.length,
      'session_duration_ms': DateTime.now().difference(_sessionStartTime).inMilliseconds,
    },
  );
    _pollingTimer?.cancel();  }
}
