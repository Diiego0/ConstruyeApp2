package com.example.construyeapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
