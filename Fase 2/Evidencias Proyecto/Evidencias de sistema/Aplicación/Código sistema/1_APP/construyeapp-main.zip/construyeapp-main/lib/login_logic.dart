// lib/login_logic.dart
import 'package:construyeapp/widgets/event_tracker.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'auth_service.dart';
import 'urls.dart';
import 'main.dart';

class LoginLogic {
  final formKey = GlobalKey<FormState>();
  final TextEditingController identifierController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool isLoading = false;
  String errorMessage = '';
  final String url = urlLogin;

  void setLoading(bool value) {
    isLoading = value;
  }

  void setErrorMessage(String message) {
    errorMessage = message;
  }

  bool isValidEmail(String email) {
    return RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email);
  }

  bool isValidRut(String rut) {
    return RegExp(r'^\d{1,8}-[0-9kK]$').hasMatch(rut);
  }

  String? validateIdentifier(String? value) {
    if (value == null || value.isEmpty) {
      return 'Por favor ingrese su email o RUT';
    }
    if (!isValidEmail(value) && !isValidRut(value)) {
      return 'Ingrese un email o RUT válido';
    }
    return null;
  }

Future<void> registerDeviceId(String rut) async {
  if (kDebugMode) {
    print('Iniciando registro de device ID para RUT: $rut');
  }
  
  final prefs = await SharedPreferences.getInstance();
  bool isRegistered = prefs.getBool('device_registered') ?? false;
  
  if (!isRegistered) {
    String? deviceToken = await FirebaseMessaging.instance.getToken();
    
    if (deviceToken != null) {
      try {
        final requestData = {
          "devicetoken": deviceToken,
          "user": rut,
        };

        if (kDebugMode) {
          print('Request Data: $requestData');
        }

        final response = await http.post(
          Uri.parse('https://construbotadmin.azurewebsites.net/api/usersdeviceid/'),
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          },
          body: json.encode(requestData),
        );
        
        if (kDebugMode) {
          print('Status Code: ${response.statusCode}');
          print('Response Body: ${response.body}');
        }
        
        if (response.statusCode == 200 || response.statusCode == 201) {
          await prefs.setBool('device_registered', true);
            tracker.capture(
              eventName: 'Device_Registration_Success',
              properties: {
                'status_code': response.statusCode,
              },
            );
          if (kDebugMode) {
            print('Dispositivo registrado exitosamente');
          }
        } else {
          if (kDebugMode) {
            tracker.capture(
              eventName: 'Device_Registration_Failed',
              properties: {
                'status_code': response.statusCode,
                'error': response.body,
              },
            );
            print('Error inesperado: ${response.statusCode}');
            print('Detalles: ${response.body}');
          }
        }
      } catch (e) {
        tracker.logError(
            errorType: 'DeviceRegistrationError',
            message: e.toString(),
            stackTrace: StackTrace.current.toString(),
            properties: {
              'rut': rut,
            },
          );
        if (kDebugMode) {
          print('Excepción durante el registro: $e');
          print('Stack trace: ${StackTrace.current}');
        }
      }
    } else {
         tracker.capture(
          eventName: 'Device_Token_Missing',
          properties: {
            'rut': rut,
          },
        );
      if (kDebugMode) {
        print('No se pudo obtener el token del dispositivo');
      }
    }
  } else {
    tracker.capture(
      eventName: 'Device_Already_Registered',
      properties: {
        'rut': rut,
      },
    );
    if (kDebugMode) {
      print('El dispositivo ya está registrado');
    }
  }
}
  
  Future<void> login(BuildContext context) async {
    if (formKey.currentState!.validate()) {
      setLoading(true);
      setErrorMessage('');
      String identifier = identifierController.text.trim();
      String password = passwordController.text;
      tracker.capture(
        eventName: 'Login_Attempt',
        properties: {
          'identifier_type': isValidEmail(identifier) ? 'email' : 'rut',
        },
      );
      try {
        if (kDebugMode) {
          print('Intentando login con: $identifier');
        }
        
        final response = await http.post(
          Uri.parse(url),
          headers: <String, String>{
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: jsonEncode(<String, String>{
            'identifier': identifier,
            'password': password,
          }),
        );

        if (kDebugMode) {
          print('Status Code: ${response.statusCode}');
          print('Response body: ${response.body}');
        }

        if (response.body.isEmpty) {
          setErrorMessage('El servidor no envió respuesta');
          return;
        }

        try {
          final responseData = json.decode(response.body);
          if (response.statusCode == 200) {
          tracker.capture(
            eventName: 'Login_Success',
            properties: {
              'user_id': responseData['user_id'].toString(),
            },
          );
            final token = responseData['token'];
            final userId = responseData['user_id'].toString();
            await AuthService().saveToken(token);
            await AuthService().saveUserId(userId);
            idUsuario = userId;
            
            // Cargar el perfil del usuario
            await AuthService().loadUserPerfilFromDB(idUsuario);
            
            // Registrar el device ID después de cargar el perfil
            final prefs = await SharedPreferences.getInstance();
            String? rut = prefs.getString('rut');
            if (rut != null) {
              await registerDeviceId(rut);
            }

            // ignore: use_build_context_synchronously
            Navigator.pushReplacementNamed(context, '/inicio_chatbot');
          } else {
            setErrorMessage(responseData['error'] ?? 'Error en la autenticación');
            tracker.capture(
              eventName: 'Login_Failed',
              properties: {
                'error': responseData['error'] ?? 'Error en la autenticación',
                'status_code': response.statusCode,
              },
            );
          }
        } on FormatException catch (e) {
          setErrorMessage('Error al procesar la respuesta del servidor: ${e.toString()}');
        }
      } catch (e) {
        tracker.capture(
          eventName: 'Login_Error',
          properties: {
            'error_type': e.runtimeType.toString(),
            'error_message': e.toString(),
          },
        );
        setErrorMessage('Error de conexión: ${e.toString()}');
      } finally {
        setLoading(false);
      }
    }
  }
}
