// ignore_for_file: use_build_context_synchronously

import 'package:construyeapp/main.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'inicio_chatbot_ui.dart';
import 'widgets/chat_message_bubble.dart';
import 'inicio_chatbot_logic.dart';

class VistaPreviewChat extends StatelessWidget {
  final String chatId;
  final List<ChatMessage> messages;

  const VistaPreviewChat({
    super.key,
    required this.chatId,
    required this.messages,
  });

  Future<Map<String, dynamic>> _getChatStatus() async {
    InicioChatBotLogic chatBotLogic = InicioChatBotLogic(
      onMessagesUpdated: (_) {},
      onWaitingForResponseChanged: (_) {},
      onChatClosed: () {},
    );

    bool hasExistingSession = await chatBotLogic.loadTokenAndConversationId();
    String storedConversationId = chatBotLogic.conversationId;

    if (kDebugMode) {
      print("DEBUG - hasExistingSession: $hasExistingSession");
      print("DEBUG - chatId actual: $chatId");
      print("DEBUG - storedConversationId: $storedConversationId");
      print("DEBUG - ID de la conversación activa: ${hasExistingSession ? storedConversationId : 'Ninguna'}");
    }

    return {
      'hasExistingSession': hasExistingSession,
      'isCurrentChat': chatId == storedConversationId,
      'activeConversationId': storedConversationId,
    };
  }

  void _handleChatButtonPress(BuildContext context) async {
    Map<String, dynamic> chatStatus = await _getChatStatus();

    if (chatStatus['hasExistingSession'] && chatStatus['isCurrentChat']) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Chat Activo'),
            content: Text('Este chat ya está activo. Puedes volver a la pantalla principal para continuar la conversación.\n\nID de la conversación activa: ${chatStatus['activeConversationId']}'),
            actions: <Widget>[
              TextButton(
                child: const Text('Entendido'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    } else {
      // No hay sesión activa o este chat no es el activo, podemos continuar con este chat
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => InicioChatBot(
            chatId: chatId,
            initialChatMode: true,
            shouldContinueConversation: true,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    Color backgroundColorTheme =
        isDarkMode ? primaryColorDarkMode : primaryColor;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Vista previa del chat', style: TextStyle(color: Colors.white)),
        backgroundColor: backgroundColorTheme,
        iconTheme: const IconThemeData(
          color: Colors.white,
        ),
      ),
      body: Container(
        color: backgroundColorTheme,
        child: CustomPaint(
          painter: ConstructionBackgroundPainter(
            iconColor: Colors.white,
          ),
          child: ListView.builder(
            itemCount: messages.length + 1,
            itemBuilder: (context, index) {
              if (index == messages.length) {
                return const SizedBox(height: 40);
              }
              return MessageBubble(
                message: messages[index],
                isLastMessage: false,
              );
            },
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: isDarkMode ? primaryColorDarkMode : primaryColor,
        onPressed: () => _handleChatButtonPress(context),
        child: const Icon(Icons.chat, color: Colors.white),
      ),
    );
  }
}