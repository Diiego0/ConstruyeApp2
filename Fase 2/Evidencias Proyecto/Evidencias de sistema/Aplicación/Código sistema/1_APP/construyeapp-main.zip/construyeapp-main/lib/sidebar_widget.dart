// lib/widgets/sidebar_widget.dart
import 'package:flutter/material.dart';
import 'main.dart';
import 'auth_service.dart';

class SidebarWidget extends StatelessWidget {
  final Function toggleSidebar;
  final Function toggleChatMode;

  const SidebarWidget({
    super.key,
    required this.toggleSidebar,
    required this.toggleChatMode,
  });

  //FALTA AGREGAR INTERACCIÓN PARA CAMBIO DE PANELES
  //EN CASO DE URGENCIA, SACARLO DE LA CARPETA WIDGETS Y TIRARLO A LIB
  //PARA QUE RECONOZCA LAS RUTAS
  Widget _buildSidebar(BuildContext context) {
    final backgroundColor = isDarkMode ? Colors.grey[850] : primaryColor;
    final backgroundAvatar = isDarkMode ? Colors.grey[700] : Colors.grey[300];
    final avatarColor = isDarkMode ? Colors.grey[300] : Colors.grey;
    final textColor = isDarkMode ? Colors.white : Colors.black;
    final buttonColor = isDarkMode ? Colors.grey[700] : Colors.white;
    final backbuttonColor = isDarkMode ? Colors.white : Colors.black;

    return Container(
      width: 250,
      decoration: BoxDecoration(
        color: backgroundColor,
      ),
      child: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  const SizedBox(height: 20),
                  CircleAvatar(
                    radius: 40,
                    backgroundColor: backgroundAvatar,
                    child: Icon(Icons.person, size: 50, color: avatarColor),
                  ),
                  const SizedBox(height: 20),
                  //necesito que se le pase parámetro de isChatMode
                  //if está en chatmode
                  _buildSidebarButton(context, Icons.home, 'Inicio',
                      'toggleChatMode', textColor, buttonColor!),
                  _buildSidebarButton(context, Icons.chat, 'Chat activo',
                      'toggleChatMode', textColor, buttonColor),

                  //botones a rutas directas
                  _buildSidebarButton(context, Icons.history, 'Historial',
                      '/historial', textColor, buttonColor),
                  _buildSidebarButton(context, Icons.people, 'Perfil',
                      '/perfil', textColor, buttonColor),
                  _buildSidebarButton(context, Icons.settings,
                      'Soporte técnico', '/soporte', textColor, buttonColor),
                ],
              ),
            ),
            _buildSidebarButton(context, Icons.exit_to_app, 'Cerrar sesión',
                '/', textColor, buttonColor),
            IconButton(
              icon: Icon(Icons.chevron_left, color: backbuttonColor),
              onPressed: () => toggleSidebar(),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSidebarButton(BuildContext context, IconData icon, String label,
      String route, Color textColor, Color buttonColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 16),
      child: ElevatedButton(
        onPressed: () async {
          if (route == 'toggleChatMode') {
            toggleChatMode();
          } else if (label == 'Cerrar sesión') {
            // Lógica para cerrar sesión
            await _handleLogout(context);
          } else {
            Navigator.of(context).pushNamed(route);
          }
          toggleSidebar(); // Cierra el sidebar después de navegar
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: buttonColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(icon, color: textColor),
            const SizedBox(width: 8),
            Text(label, style: TextStyle(color: textColor)),
          ],
        ),
      ),
    );
  }

  Future<void> _handleLogout(BuildContext context) async {
    // Borra el token
    await AuthService().clearCredentials();

    // Navega a la pantalla de inicio (login)
    //Navigator.of(context).pushNamedAndRemoveUntil('/', (route) => false);
    Navigator.of(context).pushNamed('/');

    // Opcional: Mostrar un SnackBar para confirmar el cierre de sesión
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Sesión cerrada exitosamente')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return _buildSidebar(context);
  }
}
